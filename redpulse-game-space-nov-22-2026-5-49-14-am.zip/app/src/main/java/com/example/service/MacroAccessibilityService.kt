package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.example.data.ExecutionMode
import com.example.data.MacroBindingEntity
import com.example.data.MacroStepEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MacroPulseEvent(
    val x: Float,
    val y: Float,
    val label: String,
    val timestampMs: Long = System.currentTimeMillis()
)

class MacroAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeInstance = this
        _isConnected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Service is strictly for user-configured dispatchGesture macro execution
    }

    override fun onInterrupt() {
        // No-op
    }

    override fun onDestroy() {
        super.onDestroy()
        if (activeInstance === this) {
            activeInstance = null
        }
        _isConnected.value = false
        serviceScope.cancel()
    }

    private fun buildStepPath(step: MacroStepEntity): Path {
        val startX = step.targetX.coerceAtLeast(1f)
        val startY = step.targetY.coerceAtLeast(1f)
        return Path().apply {
            moveTo(startX, startY)
            if (step.isSwipe) {
                val endX = step.endX.coerceAtLeast(1f)
                val endY = step.endY.coerceAtLeast(1f)
                if (endX != startX || endY != startY) {
                    lineTo(endX, endY)
                }
            }
        }
    }

    fun performSingleTap(
        x: Float,
        y: Float,
        durationMs: Long = 35L,
        label: String = ""
    ): Boolean {
        val safeX = x.coerceAtLeast(1f)
        val safeY = y.coerceAtLeast(1f)
        val safeDuration = durationMs.coerceIn(15L, 600L)

        val path = Path().apply { moveTo(safeX, safeY) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, safeDuration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        val dispatched = dispatchGesture(gesture, null, null)
        if (dispatched) {
            _pulseEvents.tryEmit(MacroPulseEvent(safeX, safeY, label))
        }
        return dispatched
    }

    fun performAdvancedMacro(
        macro: MacroBindingEntity,
        steps: List<MacroStepEntity>
    ): Boolean {
        if (steps.isEmpty()) return false
        val ordered = steps.sortedBy { it.stepIndex }
        val mode = ExecutionMode.fromString(macro.executionMode)
        val repeats = macro.repeatCount.coerceIn(1, 5)

        serviceScope.launch {
            repeat(repeats) { iteration ->
                when (mode) {
                    ExecutionMode.MULTI_TOUCH -> {
                        dispatchSimultaneousMultiTouch(macro.name, ordered)
                        val maxHold = ordered.maxOfOrNull { it.holdDurationMs.coerceIn(20L, 600L) + it.delayBeforeMs.coerceIn(0L, 500L) } ?: 60L
                        if (iteration < repeats - 1) {
                            delay(maxHold + 45L)
                        }
                    }
                    ExecutionMode.SEQUENTIAL -> {
                        for (step in ordered) {
                            if (step.delayBeforeMs > 0L) {
                                delay(step.delayBeforeMs)
                            }
                            val path = buildStepPath(step)
                            val dur = step.holdDurationMs.coerceIn(20L, 800L)
                            val stroke = GestureDescription.StrokeDescription(path, 0L, dur)
                            val gesture = GestureDescription.Builder().addStroke(stroke).build()
                            if (dispatchGesture(gesture, null, null)) {
                                _pulseEvents.tryEmit(
                                    MacroPulseEvent(
                                        x = step.targetX.coerceAtLeast(1f),
                                        y = step.targetY.coerceAtLeast(1f),
                                        label = macro.name
                                    )
                                )
                            }
                            delay(dur + 20L)
                        }
                        if (iteration < repeats - 1) {
                            delay(60L)
                        }
                    }
                }
            }
        }
        return true
    }

    private fun dispatchSimultaneousMultiTouch(
        macroName: String,
        steps: List<MacroStepEntity>
    ): Boolean {
        val maxStrokes = GestureDescription.getMaxStrokeCount().coerceAtLeast(2)
        val builder = GestureDescription.Builder()
        val limitedSteps = steps.take(maxStrokes)

        limitedSteps.forEach { step ->
            val path = buildStepPath(step)
            val startDelay = step.delayBeforeMs.coerceIn(0L, 500L)
            val duration = step.holdDurationMs.coerceIn(25L, 800L)
            builder.addStroke(GestureDescription.StrokeDescription(path, startDelay, duration))
        }

        val dispatched = dispatchGesture(builder.build(), null, null)
        if (dispatched) {
            limitedSteps.forEachIndexed { idx, step ->
                _pulseEvents.tryEmit(
                    MacroPulseEvent(
                        x = step.targetX.coerceAtLeast(1f),
                        y = step.targetY.coerceAtLeast(1f),
                        label = macroName,
                        timestampMs = System.currentTimeMillis() + idx
                    )
                )
            }
        }
        return dispatched
    }

    companion object {
        @Volatile
        private var activeInstance: MacroAccessibilityService? = null

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _pulseEvents = MutableSharedFlow<MacroPulseEvent>(extraBufferCapacity = 32)
        val pulseEvents: SharedFlow<MacroPulseEvent> = _pulseEvents.asSharedFlow()

        fun dispatchMacro(macro: MacroBindingEntity, steps: List<MacroStepEntity>): Boolean {
            val service = activeInstance ?: return false
            return service.performAdvancedMacro(macro, steps)
        }

        fun dispatchSinglePoint(x: Float, y: Float, label: String = ""): Boolean {
            val service = activeInstance ?: return false
            return service.performSingleTap(x, y, 35L, label)
        }
    }
}
