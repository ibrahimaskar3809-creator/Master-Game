package com.example.overlay

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.EditLocationAlt
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.KeyboardDoubleArrowLeft
import androidx.compose.material.icons.filled.KeyboardDoubleArrowRight
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.OverlayRuntimeState
import com.example.data.ExecutionMode
import com.example.data.GestureTriggerType
import com.example.data.ProfileWithMacros
import com.example.data.SidebarSide
import com.example.data.TriggerMode
import com.example.engine.TelemetrySnapshot
import com.example.engine.VoiceEngineState
import com.example.ui.theme.CrimsonGlass
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.MechaBorder
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBright
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TacticalAmber
import com.example.ui.theme.TacticalEmerald
import com.example.ui.theme.TacticalRose
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun OverlaySidebarUi(
    telemetry: TelemetrySnapshot,
    voiceState: VoiceEngineState,
    runtimeState: OverlayRuntimeState,
    activeProfile: ProfileWithMacros?,
    allProfiles: List<ProfileWithMacros>,
    isAccessibilityReady: Boolean,
    onCollapseToPill: () -> Unit,
    onEnterHideMode: () -> Unit,
    onStopOverlay: () -> Unit,
    onToggleVoice: () -> Unit,
    onToggleEditPoints: () -> Unit,
    onFlipSidebarSide: () -> Unit,
    onToggleCrosshair: () -> Unit,
    onToggleDnd: () -> Unit,
    onSelectProfile: (Long) -> Unit,
    onExecuteMacro: (Long) -> Unit,
    onToggleMacroEnabled: (Long, Boolean) -> Unit
) {
    val profile = activeProfile?.profile
    val side = SidebarSide.fromString(profile?.sidebarSide ?: SidebarSide.LEFT.name)
    val panelShape = CutCornerShape(
        topStart = if (side == SidebarSide.RIGHT) 18.dp else 4.dp,
        topEnd = if (side == SidebarSide.LEFT) 18.dp else 4.dp,
        bottomStart = if (side == SidebarSide.RIGHT) 18.dp else 4.dp,
        bottomEnd = if (side == SidebarSide.LEFT) 18.dp else 4.dp
    )

    var showProfileMenu by remember { mutableStateOf(false) }

    val pulseTransition = rememberInfiniteTransition(label = "hudPulse")
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Box(
        modifier = Modifier
            .width(274.dp)
            .heightIn(max = 560.dp)
            .clip(panelShape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xEB0A0C12),
                        Color(0xE810141E),
                        Color(0xEB090A10)
                    )
                )
            )
            .border(
                width = 1.4.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        NeonRed,
                        NeonRed.copy(alpha = 0.35f),
                        MechaBorder
                    )
                ),
                shape = panelShape
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Top REDMAGIC Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(NeonRed.copy(alpha = pulseAlpha))
                    )
                    Text(
                        text = "REDPULSE",
                        fontFamily = OrbitronFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextPrimary,
                        letterSpacing = 1.2.sp
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(
                        onClick = onEnterHideMode,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("overlay_hide_mode_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.VisibilityOff,
                            contentDescription = "وضع الإخفاء الكامل",
                            tint = CyberCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onCollapseToPill,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("overlay_collapse_btn")
                    ) {
                        Icon(
                            imageVector = if (side == SidebarSide.LEFT) {
                                Icons.Default.KeyboardDoubleArrowLeft
                            } else {
                                Icons.Default.KeyboardDoubleArrowRight
                            },
                            contentDescription = "تصغير الشريط",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onStopOverlay,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("overlay_close_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إيقاف التراكب",
                            tint = NeonRedBright,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Active Profile Switcher Chip
            Box(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp))
                        .background(ObsidianCard)
                        .border(1.dp, MechaBorder, CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp))
                        .clickable { showProfileMenu = true }
                        .padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = profile?.name ?: "بدون ملف",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${activeProfile?.macros?.size ?: 0} أوامر ماكرو • ${profile?.genreTag ?: "HUD"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }
                    Text(
                        text = "تبديل ▾",
                        style = MaterialTheme.typography.labelLarge,
                        color = NeonRedBright
                    )
                }

                DropdownMenu(
                    expanded = showProfileMenu,
                    onDismissRequest = { showProfileMenu = false },
                    modifier = Modifier.background(ObsidianElevated)
                ) {
                    allProfiles.forEach { item ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = item.profile.name,
                                    color = if (item.profile.isActive) NeonRedBright else TextPrimary
                                )
                            },
                            onClick = {
                                showProfileMenu = false
                                onSelectProfile(item.profile.id)
                            }
                        )
                    }
                }
            }

            // Real-Time Performance Telemetry Grid (FPS, PING, CPU, GPU)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp))
                    .background(Color(0xAA111520))
                    .border(1.dp, NeonRed.copy(alpha = 0.25f), CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TelemetryTile(
                        label = "FPS",
                        value = "${telemetry.fps}",
                        subValue = "/${telemetry.refreshRate}Hz",
                        accent = if (telemetry.fps >= 50) TacticalEmerald else TacticalAmber,
                        modifier = Modifier.weight(1f)
                    )
                    val pingColor = when {
                        telemetry.pingMs < 0 -> TacticalRose
                        telemetry.pingMs <= 55 -> TacticalEmerald
                        telemetry.pingMs <= 110 -> TacticalAmber
                        else -> TacticalRose
                    }
                    TelemetryTile(
                        label = "PING",
                        value = if (telemetry.pingMs > 0) "${telemetry.pingMs}" else "--",
                        subValue = if (telemetry.pingMs > 0) "ms" else "OFFLINE",
                        accent = pingColor,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Live FPS Sparkline
                FpsSparkline(
                    history = telemetry.fpsHistory,
                    maxRefresh = telemetry.refreshRate,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(24.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TelemetryBarTile(
                        label = "CPU",
                        percent = telemetry.cpuPercent,
                        extraText = "${telemetry.cpuPercent}% • ${telemetry.cpuFreqMhz}MHz",
                        accent = CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryBarTile(
                        label = if (telemetry.isCharging) "BAT ⚡" else "BAT",
                        percent = telemetry.batteryPercent,
                        extraText = "${telemetry.batteryPercent}% • ${telemetry.tempCelsius.toInt()}°C",
                        accent = if (telemetry.batteryPercent <= 20) TacticalRose else TacticalEmerald,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "GPU ${telemetry.gpuPercent}% • RAM ${telemetry.ramUsedPercent}%",
                        fontFamily = RajdhaniFontFamily,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = "${telemetry.batteryVoltageMv} mV",
                        fontFamily = RajdhaniFontFamily,
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }

            // Voice Engine Live Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (voiceState.isListening) CrimsonGlass else ObsidianCard)
                    .border(
                        1.dp,
                        if (voiceState.isListening) NeonRed else MechaBorder,
                        RoundedCornerShape(8.dp)
                    )
                    .clickable(onClick = onToggleVoice)
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = if (voiceState.isListening) Icons.Default.Mic else Icons.Default.MicOff,
                    contentDescription = "تبديل الأوامر الصوتية",
                    tint = if (voiceState.isListening) NeonRedBright else TextMuted,
                    modifier = Modifier.size(18.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (voiceState.isListening) "الأوامر الصوتية نشطة" else "تفعيل الأوامر الصوتية",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextPrimary,
                        maxLines = 1
                    )
                    val detail = voiceState.lastMatchedLabel
                        ?: voiceState.lastTranscript.ifBlank { voiceState.statusMessage }
                    Text(
                        text = detail,
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                        color = if (voiceState.isListening) CyberCyan else TextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (voiceState.isListening) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = null,
                        tint = NeonRedBright,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Quick Gaming Shortcut Grid
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OverlayShortcutTile(
                        icon = Icons.Default.EditLocationAlt,
                        label = if (runtimeState.isEditingPoints) "حفظ النقاط" else "سحب النقاط",
                        active = runtimeState.isEditingPoints,
                        onClick = onToggleEditPoints,
                        modifier = Modifier.weight(1f)
                    )
                    OverlayShortcutTile(
                        icon = Icons.Default.CenterFocusStrong,
                        label = "تصويب",
                        active = profile?.showCrosshair == true,
                        onClick = onToggleCrosshair,
                        modifier = Modifier.weight(1f)
                    )
                    OverlayShortcutTile(
                        icon = Icons.Default.DoNotDisturbOn,
                        label = "تركيز DND",
                        active = runtimeState.isDndActive,
                        onClick = onToggleDnd,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OverlayShortcutTile(
                        icon = Icons.Default.SwapHoriz,
                        label = if (side == SidebarSide.LEFT) "نقل لليمين" else "نقل لليسار",
                        active = false,
                        onClick = onFlipSidebarSide,
                        modifier = Modifier.weight(1f)
                    )
                    OverlayShortcutTile(
                        icon = Icons.Default.VisibilityOff,
                        label = "إخفاء كامل",
                        active = false,
                        onClick = onEnterHideMode,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Macro Quick-Trigger List
            val macros = activeProfile?.sortedMacros.orEmpty()
            if (macros.isNotEmpty()) {
                Text(
                    text = "نقاط الماكرو (${macros.size})",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextSecondary
                )
                if (!isAccessibilityReady) {
                    Text(
                        text = "تنبيه: خدمة الوصول متوقفة — فعّلها لتنفيذ اللمس",
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                        color = TacticalAmber
                    )
                }
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    macros.forEach { macroWithSteps ->
                        val macro = macroWithSteps.macro
                        val mode = TriggerMode.fromString(macro.triggerMode)
                        val stepCount = macroWithSteps.steps.size
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(ObsidianCard)
                                .border(1.dp, MechaBorder, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(macro.accentColorHex))
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = macro.name,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                val execMode = ExecutionMode.fromString(macro.executionMode)
                                val gestureType = GestureTriggerType.fromString(macro.gestureTrigger)
                                val execTag = if (execMode == ExecutionMode.MULTI_TOUCH) "متعدد اللمس" else "$stepCount خطوة"
                                val triggerHint = when (mode) {
                                    TriggerMode.VOICE -> "$execTag • صوتي: \"${macro.voiceKeyword}\""
                                    TriggerMode.TAP_POINT -> "$execTag • نقطة نقر"
                                    TriggerMode.GESTURE -> "$execTag • ${gestureType.labelAr}"
                                    TriggerMode.BOTH -> buildString {
                                        append(execTag)
                                        if (macro.voiceKeyword.isNotBlank()) append(" • \"${macro.voiceKeyword}\"")
                                        if (gestureType != GestureTriggerType.NONE) append(" • ${gestureType.labelAr}")
                                    }
                                }
                                Text(
                                    text = triggerHint,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 10.sp),
                                    color = TextMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(
                                onClick = { onExecuteMacro(macro.id) },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "تشغيل ${macro.name}",
                                    tint = TacticalEmerald,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Switch(
                                checked = macro.isEnabled,
                                onCheckedChange = { onToggleMacroEnabled(macro.id, it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = TextPrimary,
                                    checkedTrackColor = NeonRed,
                                    uncheckedThumbColor = TextMuted,
                                    uncheckedTrackColor = ObsidianVoid
                                ),
                                modifier = Modifier.height(24.dp)
                            )
                        }
                    }
                }
            }

            AnimatedVisibility(visible = runtimeState.lastStatusMessage != null) {
                Text(
                    text = runtimeState.lastStatusMessage.orEmpty(),
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                    color = CyberCyan,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun TelemetryTile(
    label: String,
    value: String,
    subValue: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(ObsidianVoid.copy(alpha = 0.7f))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            fontFamily = RajdhaniFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = TextMuted
        )
        Row(
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = value,
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = accent
            )
            Text(
                text = subValue,
                fontFamily = RajdhaniFontFamily,
                fontSize = 11.sp,
                color = TextSecondary,
                modifier = Modifier.padding(bottom = 2.dp)
            )
        }
    }
}

@Composable
private fun TelemetryBarTile(
    label: String,
    percent: Int,
    extraText: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(ObsidianVoid.copy(alpha = 0.7f))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                fontFamily = RajdhaniFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextMuted
            )
            Text(
                text = extraText,
                fontFamily = RajdhaniFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextPrimary
            )
        }
        LinearProgressIndicator(
            progress = { (percent / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = accent,
            trackColor = MechaBorder
        )
    }
}

@Composable
private fun FpsSparkline(
    history: List<Int>,
    maxRefresh: Int,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (history.size < 2) return@Canvas
        val maxVal = maxRefresh.coerceAtLeast(60).toFloat()
        val stepX = size.width / (history.size - 1).coerceAtLeast(1)
        val path = Path()
        history.forEachIndexed { idx, fps ->
            val x = idx * stepX
            val ratio = (fps / maxVal).coerceIn(0.05f, 1f)
            val y = size.height - (ratio * size.height)
            if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(
            path = path,
            color = TacticalEmerald,
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )
        drawLine(
            color = MechaBorder.copy(alpha = 0.5f),
            start = Offset(0f, size.height),
            end = Offset(size.width, size.height),
            strokeWidth = 1.dp.toPx()
        )
    }
}

@Composable
private fun OverlayShortcutTile(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(CutCornerShape(topStart = 7.dp, bottomEnd = 7.dp))
            .background(if (active) CrimsonGlass else ObsidianCard)
            .border(
                1.dp,
                if (active) NeonRed else MechaBorder,
                CutCornerShape(topStart = 7.dp, bottomEnd = 7.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 7.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (active) NeonRedBright else TextSecondary,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 10.sp),
            color = if (active) TextPrimary else TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
