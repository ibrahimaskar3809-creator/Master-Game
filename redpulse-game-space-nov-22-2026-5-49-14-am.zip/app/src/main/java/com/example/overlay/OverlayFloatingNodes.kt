package com.example.overlay

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GestureTriggerType
import com.example.data.SidebarSide
import com.example.ui.theme.CairoFontFamily
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBright
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TextPrimary
import kotlin.math.abs

@Composable
fun FloatingEdgePillUi(
    side: SidebarSide,
    onExpand: () -> Unit,
    onGestureDetected: (GestureTriggerType) -> Unit
) {
    val shape = RoundedCornerShape(
        topStart = if (side == SidebarSide.RIGHT) 14.dp else 0.dp,
        bottomStart = if (side == SidebarSide.RIGHT) 14.dp else 0.dp,
        topEnd = if (side == SidebarSide.LEFT) 14.dp else 0.dp,
        bottomEnd = if (side == SidebarSide.LEFT) 14.dp else 0.dp
    )

    var accumX by remember { mutableFloatStateOf(0f) }
    var accumY by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = Modifier
            .width(26.dp)
            .height(114.dp)
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xD90E1118), Color(0xE6FF1E2D), Color(0xD90E1118))
                )
            )
            .border(1.2.dp, NeonRedBright, shape)
            .pointerInput(side) {
                detectTapGestures(
                    onTap = { onExpand() },
                    onDoubleTap = { onGestureDetected(GestureTriggerType.DOUBLE_TAP) }
                )
            }
            .pointerInput(side) {
                detectDragGestures(
                    onDragStart = {
                        accumX = 0f
                        accumY = 0f
                    },
                    onDragEnd = {
                        val threshold = 32f
                        when {
                            abs(accumY) > abs(accumX) && accumY < -threshold -> {
                                onGestureDetected(GestureTriggerType.SWIPE_UP)
                            }
                            abs(accumY) > abs(accumX) && accumY > threshold -> {
                                onGestureDetected(GestureTriggerType.SWIPE_DOWN)
                            }
                            abs(accumX) > threshold -> {
                                val inward = if (side == SidebarSide.LEFT) accumX > threshold else accumX < -threshold
                                if (inward) {
                                    onGestureDetected(GestureTriggerType.SWIPE_INWARD)
                                }
                            }
                        }
                    }
                ) { change, dragAmount ->
                    change.consume()
                    accumX += dragAmount.x
                    accumY += dragAmount.y
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .width(3.5.dp)
                .height(42.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(TextPrimary)
        )
    }
}

@Composable
fun DraggableTargetReticleUi(
    label: String,
    stepNumber: Int,
    coordX: Int,
    coordY: Int,
    accentColor: Color,
    onDragDelta: (Float, Float) -> Unit,
    onDragEnd: () -> Unit,
    onTapTest: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = onDragEnd,
                    onDragCancel = onDragEnd
                ) { change, dragAmount ->
                    change.consume()
                    onDragDelta(dragAmount.x, dragAmount.y)
                }
            }
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(ObsidianVoid.copy(alpha = 0.72f))
                .border(2.dp, accentColor, CircleShape)
                .clickable(onClick = onTapTest),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.GpsFixed,
                contentDescription = label,
                tint = accentColor,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = "$stepNumber",
                fontFamily = RajdhaniFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextPrimary,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(3.dp)
            )
        }
        Text(
            text = "$label ($coordX,$coordY)",
            fontFamily = CairoFontFamily,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            modifier = Modifier
                .padding(top = 2.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(ObsidianVoid.copy(alpha = 0.85f))
                .padding(horizontal = 5.dp, vertical = 1.dp)
        )
    }
}

@Composable
fun TapPointTriggerButtonUi(
    label: String,
    accentColor: Color,
    isEditing: Boolean,
    coordX: Int,
    coordY: Int,
    onClick: () -> Unit,
    onDragDelta: (Float, Float) -> Unit,
    onDragEnd: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp))
            .background(ObsidianVoid.copy(alpha = if (isEditing) 0.88f else 0.58f))
            .border(
                width = 1.3.dp,
                color = accentColor.copy(alpha = if (isEditing) 1f else 0.75f),
                shape = CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp)
            )
            .then(
                if (isEditing) {
                    Modifier.pointerInput(Unit) {
                        detectDragGestures(
                            onDragEnd = onDragEnd,
                            onDragCancel = onDragEnd
                        ) { change, dragAmount ->
                            change.consume()
                            onDragDelta(dragAmount.x, dragAmount.y)
                        }
                    }
                } else {
                    Modifier.clickable(onClick = onClick)
                }
            )
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Icon(
            imageVector = Icons.Default.TouchApp,
            contentDescription = label,
            tint = accentColor,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = if (isEditing) "$label ($coordX,$coordY)" else label,
            fontFamily = CairoFontFamily,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
    }
}

@Composable
fun HideToggleZoneUi(
    isEditing: Boolean,
    isFullHideMode: Boolean,
    coordX: Int,
    coordY: Int,
    onToggleOverlay: () -> Unit,
    onDragDelta: (Float, Float) -> Unit,
    onDragEnd: () -> Unit
) {
    val bgAlpha = when {
        isEditing -> 0.85f
        isFullHideMode -> 0.04f
        else -> 0.45f
    }
    val borderAlpha = when {
        isEditing -> 1f
        isFullHideMode -> 0.14f
        else -> 0.65f
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = if (isEditing) {
            Modifier.pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = onDragEnd,
                    onDragCancel = onDragEnd
                ) { change, dragAmount ->
                    change.consume()
                    onDragDelta(dragAmount.x, dragAmount.y)
                }
            }
        } else {
            Modifier
        }
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(ObsidianVoid.copy(alpha = bgAlpha))
                .border(1.5.dp, CyberCyan.copy(alpha = borderAlpha), CircleShape)
                .clickable(onClick = onToggleOverlay),
            contentAlignment = Alignment.Center
        ) {
            if (isEditing || !isFullHideMode) {
                Icon(
                    imageVector = Icons.Default.Visibility,
                    contentDescription = "منطقة إظهار وإخفاء الواجهة",
                    tint = CyberCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
        if (isEditing) {
            Text(
                text = "إظهار/إخفاء ($coordX,$coordY)",
                fontFamily = CairoFontFamily,
                fontSize = 10.sp,
                color = CyberCyan,
                modifier = Modifier
                    .padding(top = 2.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(ObsidianVoid.copy(alpha = 0.85f))
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            )
        }
    }
}

@Composable
fun TacticalCrosshairUi() {
    Canvas(modifier = Modifier.size(36.dp)) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val gap = 4.dp.toPx()
        val arm = 10.dp.toPx()
        val stroke = 2.dp.toPx()

        drawCircle(color = NeonRedBright, radius = 2.2.dp.toPx(), center = center)
        drawCircle(
            color = NeonRed.copy(alpha = 0.6f),
            radius = 12.dp.toPx(),
            center = center,
            style = Stroke(width = 1.2.dp.toPx())
        )
        drawLine(NeonRedBright, Offset(center.x - gap - arm, center.y), Offset(center.x - gap, center.y), stroke)
        drawLine(NeonRedBright, Offset(center.x + gap, center.y), Offset(center.x + gap + arm, center.y), stroke)
        drawLine(NeonRedBright, Offset(center.x, center.y - gap - arm), Offset(center.x, center.y - gap), stroke)
        drawLine(NeonRedBright, Offset(center.x, center.y + gap), Offset(center.x, center.y + gap + arm), stroke)
    }
}

@Composable
fun GesturePulseRingUi(pulseKey: Long) {
    val progress = remember(pulseKey) { Animatable(0f) }
    LaunchedEffect(pulseKey) {
        progress.snapTo(0f)
        progress.animateTo(1f, animationSpec = tween(durationMillis = 320))
    }

    Canvas(modifier = Modifier.size(56.dp)) {
        val alpha = (1f - progress.value).coerceIn(0f, 1f)
        val radius = (8.dp.toPx() + progress.value * 18.dp.toPx())
        drawCircle(
            color = NeonRedBright.copy(alpha = alpha),
            radius = radius,
            style = Stroke(width = 3.dp.toPx())
        )
        drawCircle(
            color = CyberCyan.copy(alpha = alpha * 0.7f),
            radius = radius * 0.55f
        )
    }
}
