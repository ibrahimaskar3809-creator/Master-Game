package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.GameProfileEntity
import com.example.data.ProfileWithMacros
import com.example.data.SidebarSide
import com.example.data.TriggerMode
import com.example.ui.theme.CrimsonGlass
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.MechaBorder
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBright
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TacticalEmerald
import com.example.ui.theme.TacticalRose
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ProfilesScreen(
    profiles: List<ProfileWithMacros>,
    onSwitchProfile: (Long) -> Unit,
    onCreateProfile: (
        name: String,
        genre: String,
        side: SidebarSide,
        showKeyword: String,
        hideKeyword: String,
        toggleMode: TriggerMode
    ) -> Unit,
    onDuplicateProfile: (ProfileWithMacros) -> Unit,
    onDeleteProfile: (GameProfileEntity) -> Unit
) {
    var showCreateDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            MechaSectionCard(
                title = "ملفات الإعدادات (Game Profiles)",
                subtitle = "احفظ توزيعات النقاط والأوامر الصوتية لكل لعبة وبدّل بينها بلمسة واحدة"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    profiles.forEach { item ->
                        val profile = item.profile
                        val isActive = profile.isActive
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp))
                                .background(if (isActive) CrimsonGlass else ObsidianCard)
                                .border(
                                    width = if (isActive) 1.5.dp else 1.dp,
                                    color = if (isActive) NeonRed else MechaBorder,
                                    shape = CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp)
                                )
                                .clickable { onSwitchProfile(profile.id) }
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.SportsEsports,
                                        contentDescription = null,
                                        tint = if (isActive) NeonRedBright else TextSecondary,
                                        modifier = Modifier.size(26.dp)
                                    )
                                    Column {
                                        Text(
                                            text = profile.name,
                                            style = MaterialTheme.typography.titleLarge,
                                            color = TextPrimary
                                        )
                                        Text(
                                            text = "${profile.genreTag} • ${item.macros.size} أوامر ماكرو",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = TextMuted
                                        )
                                    }
                                }
                                if (isActive) {
                                    Row(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(TacticalEmerald.copy(alpha = 0.16f))
                                            .padding(horizontal = 10.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = "نشط",
                                            tint = TacticalEmerald,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = "نشط",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = TacticalEmerald
                                        )
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "إظهار: \"${profile.overlayShowVoiceKeyword}\" • إخفاء: \"${profile.overlayHideVoiceKeyword}\" • ${SidebarSide.fromString(profile.sidebarSide).labelAr}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CyberCyan,
                                    modifier = Modifier.weight(1f)
                                )
                                Row {
                                    IconButton(onClick = { onDuplicateProfile(item) }) {
                                        Icon(
                                            imageVector = Icons.Default.ContentCopy,
                                            contentDescription = "نسخ ${profile.name}",
                                            tint = TextSecondary
                                        )
                                    }
                                    if (profiles.size > 1) {
                                        IconButton(onClick = { onDeleteProfile(profile) }) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "حذف ${profile.name}",
                                                tint = TacticalRose
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(76.dp))
        }

        FloatingActionButton(
            onClick = { showCreateDialog = true },
            containerColor = NeonRed,
            contentColor = TextPrimary,
            shape = CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_profile_fab")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "ملف جديد")
                Text("ملف جديد", style = MaterialTheme.typography.labelLarge)
            }
        }
    }

    if (showCreateDialog) {
        CreateProfileDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { name, genre, side, showKey, hideKey, mode ->
                onCreateProfile(name, genre, side, showKey, hideKey, mode)
                showCreateDialog = false
            }
        )
    }
}

@Composable
private fun CreateProfileDialog(
    onDismiss: () -> Unit,
    onCreate: (
        name: String,
        genre: String,
        side: SidebarSide,
        showKeyword: String,
        hideKeyword: String,
        toggleMode: TriggerMode
    ) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf("FPS / Action") }
    var side by remember { mutableStateOf(SidebarSide.LEFT) }
    var showKey by remember { mutableStateOf("إظهار") }
    var hideKey by remember { mutableStateOf("إخفاء") }
    var toggleMode by remember { mutableStateOf(TriggerMode.BOTH) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ObsidianElevated,
        title = { Text("إنشاء ملف إعدادات جديد", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم اللعبة / الملف") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_name_input")
                )
                OutlinedTextField(
                    value = genre,
                    onValueChange = { genre = it },
                    label = { Text("التصنيف (مثال: Battle Royale)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SidebarSide.entries.forEach { s ->
                        FilterChip(
                            selected = side == s,
                            onClick = { side = s },
                            label = { Text(s.labelAr) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CrimsonGlass,
                                selectedLabelColor = NeonRedBright
                            )
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = showKey,
                        onValueChange = { showKey = it },
                        label = { Text("أمر الإظهار") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = hideKey,
                        onValueChange = { hideKey = it },
                        label = { Text("أمر الإخفاء") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onCreate(
                        name.ifBlank { "ملف جديد" },
                        genre,
                        side,
                        showKey,
                        hideKey,
                        toggleMode
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
                modifier = Modifier.testTag("confirm_create_profile_btn")
            ) {
                Text("إنشاء وتفعيل")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = TextSecondary)
            }
        }
    )
}
