package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EditLocationAlt
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ExecutionMode
import com.example.data.GestureTriggerType
import com.example.data.MacroBindingEntity
import com.example.data.MacroStepEntity
import com.example.data.MacroWithSteps
import com.example.data.ProfileWithMacros
import com.example.data.TriggerMode
import com.example.engine.VoiceEngineState
import com.example.ui.theme.CrimsonGlass
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.MechaBorder
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBright
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TacticalAmber
import com.example.ui.theme.TacticalEmerald
import com.example.ui.theme.TacticalRose
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.abs

@Composable
fun MacroStudioScreen(
    activeProfile: ProfileWithMacros?,
    voiceState: VoiceEngineState,
    isAccessibilityReady: Boolean,
    isOverlayRunning: Boolean,
    onToggleVoice: () -> Unit,
    onOpenFloatingPointEditor: () -> Unit,
    onTriggerGesture: (GestureTriggerType) -> Boolean,
    onSaveMacro: (
        existing: MacroBindingEntity?,
        profileId: Long,
        name: String,
        triggerMode: TriggerMode,
        voiceKeyword: String,
        triggerZoneX: Float,
        triggerZoneY: Float,
        accentColorHex: Long,
        executionMode: ExecutionMode,
        repeatCount: Int,
        gestureTrigger: GestureTriggerType,
        steps: List<MacroStepEntity>
    ) -> Unit,
    onToggleMacroEnabled: (Long, Boolean) -> Unit,
    onDeleteMacro: (Long) -> Unit,
    onTestMacro: (Long) -> Unit
) {
    var editingMacro by remember { mutableStateOf<MacroWithSteps?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var lastGestureFeedback by remember { mutableStateOf<String?>(null) }

    val profile = activeProfile?.profile

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Fast Voice Command Engine Live Monitor
            MechaSectionCard(
                title = "محرك الأوامر الصوتية السريع",
                subtitle = "التقاط فوري للكلمات المفتاحية وتنفيذ الماكرو أو إظهار/إخفاء الواجهة"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = voiceState.statusMessage,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (voiceState.isListening) TacticalEmerald else TextPrimary
                        )
                        if (voiceState.lastTranscript.isNotBlank()) {
                            Text(
                                text = "آخر صوت ملتقط: \"${voiceState.lastTranscript}\"",
                                style = MaterialTheme.typography.bodyMedium,
                                color = CyberCyan
                            )
                        }
                        if (voiceState.lastMatchedLabel != null) {
                            Text(
                                text = "آخر إجراء منفّذ: ${voiceState.lastMatchedLabel}",
                                style = MaterialTheme.typography.labelLarge,
                                color = NeonRedBright
                            )
                        }
                    }

                    Button(
                        onClick = onToggleVoice,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (voiceState.isListening) ObsidianElevated else NeonRed
                        ),
                        shape = CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("studio_voice_toggle_btn")
                    ) {
                        Icon(
                            imageVector = if (voiceState.isListening) Icons.Default.Mic else Icons.Default.MicOff,
                            contentDescription = null,
                            tint = if (voiceState.isListening) NeonRedBright else TextPrimary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (voiceState.isListening) "إيقاف" else "تشغيل الصوت")
                    }
                }

                if (voiceState.isListening) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = NeonRedBright,
                            modifier = Modifier.size(18.dp)
                        )
                        LinearProgressIndicator(
                            progress = { (voiceState.audioRmsDb / 10f).coerceIn(0.05f, 1f) },
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = NeonRedBright,
                            trackColor = ObsidianVoid
                        )
                    }
                }
            }

            // Interactive Gesture Trigger Test Pad
            MechaSectionCard(
                title = "منطقة اختبار الإيماءات السريعة",
                subtitle = "اسحب للأعلى أو للأسفل أو انقر مرتين لاختبار الماكرو المرتبط بالإيماءات (متاح أيضاً على الحافة العائمة)"
            ) {
                var accumX by remember { mutableFloatStateOf(0f) }
                var accumY by remember { mutableFloatStateOf(0f) }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(92.dp)
                        .clip(CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp))
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(ObsidianCard, Color(0xFF1A1018), ObsidianCard)
                            )
                        )
                        .border(1.dp, CyberCyan.copy(alpha = 0.45f), CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp))
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onDoubleTap = {
                                    val triggered = onTriggerGesture(GestureTriggerType.DOUBLE_TAP)
                                    lastGestureFeedback = if (triggered) {
                                        "تم التقاط: نقر مزدوج ⚡"
                                    } else {
                                        "نقر مزدوج ⚡ (لا يوجد ماكرو مرتبط أو خدمة الوصول متوقفة)"
                                    }
                                }
                            )
                        }
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = {
                                    accumX = 0f
                                    accumY = 0f
                                },
                                onDragEnd = {
                                    val threshold = 36f
                                    val gesture = when {
                                        abs(accumY) > abs(accumX) && accumY < -threshold -> GestureTriggerType.SWIPE_UP
                                        abs(accumY) > abs(accumX) && accumY > threshold -> GestureTriggerType.SWIPE_DOWN
                                        abs(accumX) > threshold -> GestureTriggerType.SWIPE_INWARD
                                        else -> GestureTriggerType.NONE
                                    }
                                    if (gesture != GestureTriggerType.NONE) {
                                        val triggered = onTriggerGesture(gesture)
                                        lastGestureFeedback = if (triggered) {
                                            "تم التقاط: ${gesture.labelAr}"
                                        } else {
                                            "${gesture.labelAr} (لا يوجد ماكرو مرتبط)"
                                        }
                                    }
                                }
                            ) { change, dragAmount ->
                                change.consume()
                                accumX += dragAmount.x
                                accumY += dragAmount.y
                            }
                        }
                        .testTag("gesture_test_pad"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Gesture,
                            contentDescription = "اختبار الإيماءات",
                            tint = CyberCyan,
                            modifier = Modifier.size(26.dp)
                        )
                        Text(
                            text = lastGestureFeedback ?: "اسحب ⬆ / ⬇ / ⇄ أو انقر مرتين ⚡ هنا للاختبار",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (lastGestureFeedback != null) TacticalEmerald else TextSecondary
                        )
                    }
                }
            }

            // Floating Point Drag Action Banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp))
                    .background(ObsidianCard)
                    .border(1.dp, CyberCyan.copy(alpha = 0.4f), CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.EditLocationAlt,
                    contentDescription = null,
                    tint = CyberCyan,
                    modifier = Modifier.size(26.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "ضبط إحداثيات النقاط بالسحب المباشر",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = "فعّل وضع التحرير فوق اللعبة لسحب كل نقطة لمس (X, Y) وتثبيتها بدقة",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted
                    )
                }
                OutlinedButton(
                    onClick = onOpenFloatingPointEditor,
                    enabled = isOverlayRunning,
                    modifier = Modifier.testTag("open_drag_editor_btn")
                ) {
                    Text(if (isOverlayRunning) "تفعيل السحب" else "شغّل التراكب")
                }
            }

            // Macro List
            MechaSectionCard(
                title = "نقاط اللمس وسلاسل الماكرو (${activeProfile?.macros?.size ?: 0})",
                subtitle = if (profile != null) "الملف الحالي: ${profile.name}" else "يرجى اختيار ملف إعدادات"
            ) {
                if (!isAccessibilityReady) {
                    Text(
                        text = "ملاحظة: خدمة الوصول غير مفعّلة حالياً. فعّلها من لوحة التحكم لتعمل محاكاة اللمس (dispatchGesture).",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TacticalAmber
                    )
                }

                val macros = activeProfile?.sortedMacros.orEmpty()
                if (macros.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.TouchApp,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(38.dp)
                        )
                        Text(
                            text = "لا توجد نقاط ماكرو في هذا الملف بعد",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextSecondary
                        )
                        Text(
                            text = "اضغط على زر الإضافة بالأسفل لإنشاء ماكرو لمس متعدد أو تسلسلي مرتبط بصوت أو إيماءة.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted
                        )
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        macros.forEach { item ->
                            MacroCard(
                                item = item,
                                onToggleEnabled = { onToggleMacroEnabled(item.macro.id, it) },
                                onEdit = { editingMacro = item },
                                onDelete = { onDeleteMacro(item.macro.id) },
                                onTest = { onTestMacro(item.macro.id) }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(76.dp))
        }

        if (profile != null) {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = NeonRed,
                contentColor = TextPrimary,
                shape = CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(20.dp)
                    .testTag("add_macro_fab")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة ماكرو")
                    Text("إضافة ماكرو", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }

    if (showCreateDialog && profile != null) {
        MacroEditorDialog(
            profileId = profile.id,
            existing = null,
            onDismiss = { showCreateDialog = false },
            onSave = { name, mode, keyword, trigX, trigY, colorHex, execMode, repeatCount, gestureTrigger, steps ->
                onSaveMacro(null, profile.id, name, mode, keyword, trigX, trigY, colorHex, execMode, repeatCount, gestureTrigger, steps)
                showCreateDialog = false
            }
        )
    }

    val currentEdit = editingMacro
    if (currentEdit != null && profile != null) {
        MacroEditorDialog(
            profileId = profile.id,
            existing = currentEdit,
            onDismiss = { editingMacro = null },
            onSave = { name, mode, keyword, trigX, trigY, colorHex, execMode, repeatCount, gestureTrigger, steps ->
                onSaveMacro(currentEdit.macro, profile.id, name, mode, keyword, trigX, trigY, colorHex, execMode, repeatCount, gestureTrigger, steps)
                editingMacro = null
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MacroCard(
    item: MacroWithSteps,
    onToggleEnabled: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onTest: () -> Unit
) {
    val macro = item.macro
    val mode = TriggerMode.fromString(macro.triggerMode)
    val execMode = ExecutionMode.fromString(macro.executionMode)
    val gestureType = GestureTriggerType.fromString(macro.gestureTrigger)
    val accent = Color(macro.accentColorHex)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp))
            .background(ObsidianCard)
            .border(1.dp, accent.copy(alpha = 0.45f), CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(accent)
                )
                Text(
                    text = macro.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                val badgeText = buildString {
                    append(if (execMode == ExecutionMode.MULTI_TOUCH) "متعدد اللمس (${item.steps.size})" else if (item.steps.size > 1) "تسلسلي (${item.steps.size})" else "نقطة مفردة")
                    if (macro.repeatCount > 1) append(" ×${macro.repeatCount}")
                }
                Text(
                    text = badgeText,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (execMode == ExecutionMode.MULTI_TOUCH) TacticalAmber else CyberCyan,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(ObsidianVoid)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            Switch(
                checked = macro.isEnabled,
                onCheckedChange = onToggleEnabled,
                colors = SwitchDefaults.colors(
                    checkedTrackColor = NeonRed,
                    checkedThumbColor = TextPrimary
                )
            )
        }

        // Trigger method info
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "التفعيل: ${mode.labelAr}",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            if ((mode == TriggerMode.VOICE || mode == TriggerMode.BOTH) && macro.voiceKeyword.isNotBlank()) {
                Text(
                    text = "صوتي: \"${macro.voiceKeyword}\"",
                    style = MaterialTheme.typography.labelLarge,
                    color = NeonRedBright
                )
            }
            if ((mode == TriggerMode.GESTURE || mode == TriggerMode.BOTH) && gestureType != GestureTriggerType.NONE) {
                Text(
                    text = "إيماءة: ${gestureType.labelAr}",
                    style = MaterialTheme.typography.labelLarge,
                    color = CyberCyan
                )
            }
            if (mode == TriggerMode.TAP_POINT || mode == TriggerMode.BOTH) {
                Text(
                    text = "زر اللمس: (${macro.triggerZoneX.toInt()}, ${macro.triggerZoneY.toInt()})",
                    fontFamily = RajdhaniFontFamily,
                    fontSize = 12.sp,
                    color = TacticalAmber
                )
            }
        }

        // Steps preview
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item.sortedSteps.forEachIndexed { idx, step ->
                val stepText = if (step.isSwipe) {
                    "#${idx + 1} سحب (${step.targetX.toInt()},${step.targetY.toInt()})→(${step.endX.toInt()},${step.endY.toInt()})"
                } else {
                    "#${idx + 1} (${step.targetX.toInt()}, ${step.targetY.toInt()})" +
                        if (execMode == ExecutionMode.SEQUENTIAL && step.delayBeforeMs > 0) " +${step.delayBeforeMs}ms" else ""
                }
                Text(
                    text = stepText,
                    fontFamily = RajdhaniFontFamily,
                    fontSize = 12.sp,
                    color = TextPrimary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(ObsidianVoid)
                        .border(1.dp, MechaBorder, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onTest) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = TacticalEmerald, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تجربة", color = TacticalEmerald)
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Default.Edit, contentDescription = "تعديل ${macro.name}", tint = CyberCyan)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "حذف ${macro.name}", tint = TacticalRose)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MacroEditorDialog(
    profileId: Long,
    existing: MacroWithSteps?,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        triggerMode: TriggerMode,
        voiceKeyword: String,
        triggerZoneX: Float,
        triggerZoneY: Float,
        accentColorHex: Long,
        executionMode: ExecutionMode,
        repeatCount: Int,
        gestureTrigger: GestureTriggerType,
        steps: List<MacroStepEntity>
    ) -> Unit
) {
    var name by remember { mutableStateOf(existing?.macro?.name ?: "") }
    var triggerMode by remember {
        mutableStateOf(TriggerMode.fromString(existing?.macro?.triggerMode ?: TriggerMode.VOICE.name))
    }
    var executionMode by remember {
        mutableStateOf(ExecutionMode.fromString(existing?.macro?.executionMode ?: ExecutionMode.SEQUENTIAL.name))
    }
    var repeatCount by remember { mutableIntStateOf(existing?.macro?.repeatCount ?: 1) }
    var gestureTrigger by remember {
        mutableStateOf(GestureTriggerType.fromString(existing?.macro?.gestureTrigger ?: GestureTriggerType.NONE.name))
    }
    var voiceKeyword by remember { mutableStateOf(existing?.macro?.voiceKeyword ?: "") }
    var triggerZoneXText by remember { mutableStateOf((existing?.macro?.triggerZoneX?.toInt() ?: 260).toString()) }
    var triggerZoneYText by remember { mutableStateOf((existing?.macro?.triggerZoneY?.toInt() ?: 420).toString()) }
    var selectedColor by remember { mutableLongStateOf(existing?.macro?.accentColorHex ?: 0xFFFF1E2D) }

    val colorChoices = listOf(0xFFFF1E2D, 0xFF00E5FF, 0xFFFFB300, 0xFF00E676)

    data class EditableStep(
        val x: String,
        val y: String,
        val delayMs: String,
        val isSwipe: Boolean = false,
        val endX: String = "920",
        val endY: String = "520"
    )

    val stepsState = remember {
        mutableStateListOf<EditableStep>().apply {
            val existingSteps = existing?.sortedSteps.orEmpty()
            if (existingSteps.isEmpty()) {
                add(EditableStep("840", "820", "0"))
            } else {
                existingSteps.forEach {
                    add(
                        EditableStep(
                            x = it.targetX.toInt().toString(),
                            y = it.targetY.toInt().toString(),
                            delayMs = it.delayBeforeMs.toString(),
                            isSwipe = it.isSwipe,
                            endX = if (it.endX > 0f) it.endX.toInt().toString() else "920",
                            endY = if (it.endY > 0f) it.endY.toInt().toString() else "520"
                        )
                    )
                }
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ObsidianElevated,
        title = {
            Text(
                text = if (existing == null) "إنشاء ماكرو متقدم" else "تعديل الماكرو",
                color = TextPrimary
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الوظيفة (مثال: سكوب + إطلاق)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("macro_name_input")
                )

                Text("نمط المحاكاة:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ExecutionMode.entries.forEach { em ->
                        FilterChip(
                            selected = executionMode == em,
                            onClick = { executionMode = em },
                            label = { Text(em.labelAr, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CrimsonGlass,
                                selectedLabelColor = TacticalAmber
                            )
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("التكرار:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    (1..5).forEach { count ->
                        FilterChip(
                            selected = repeatCount == count,
                            onClick = { repeatCount = count },
                            label = { Text("×$count") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CrimsonGlass,
                                selectedLabelColor = CyberCyan
                            )
                        )
                    }
                }

                Text("طريقة التفعيل:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    TriggerMode.entries.forEach { mode ->
                        FilterChip(
                            selected = triggerMode == mode,
                            onClick = { triggerMode = mode },
                            label = { Text(mode.labelAr, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CrimsonGlass,
                                selectedLabelColor = NeonRedBright
                            )
                        )
                    }
                }

                if (triggerMode == TriggerMode.VOICE || triggerMode == TriggerMode.BOTH) {
                    OutlinedTextField(
                        value = voiceKeyword,
                        onValueChange = { voiceKeyword = it },
                        label = { Text("الكلمة الصوتية (مثال: تبديل / ثلجة)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("macro_voice_keyword_input")
                    )
                }

                if (triggerMode == TriggerMode.GESTURE || triggerMode == TriggerMode.BOTH) {
                    Text("إيماءة التشغيل:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        GestureTriggerType.entries.forEach { g ->
                            FilterChip(
                                selected = gestureTrigger == g,
                                onClick = { gestureTrigger = g },
                                label = { Text(g.labelAr, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CrimsonGlass,
                                    selectedLabelColor = CyberCyan
                                )
                            )
                        }
                    }
                }

                if (triggerMode == TriggerMode.TAP_POINT || triggerMode == TriggerMode.BOTH) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = triggerZoneXText,
                            onValueChange = { triggerZoneXText = it.filter { c -> c.isDigit() } },
                            label = { Text("موقع زر التفعيل X") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = triggerZoneYText,
                            onValueChange = { triggerZoneYText = it.filter { c -> c.isDigit() } },
                            label = { Text("موقع زر التفعيل Y") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("لون النقطة:", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    colorChoices.forEach { hex ->
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(Color(hex))
                                .border(
                                    width = if (selectedColor == hex) 2.5.dp else 0.dp,
                                    color = TextPrimary,
                                    shape = CircleShape
                                )
                                .clickable { selectedColor = hex }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (executionMode == ExecutionMode.MULTI_TOUCH) {
                            "أصابع اللمس المتزامن (${stepsState.size})"
                        } else {
                            "نقاط التسلسل (${stepsState.size})"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        color = CyberCyan
                    )
                    TextButton(
                        onClick = {
                            stepsState.add(EditableStep("860", "640", if (executionMode == ExecutionMode.MULTI_TOUCH) "0" else "90"))
                        }
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("إضافة نقطة")
                    }
                }

                stepsState.forEachIndexed { index, step ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(ObsidianCard)
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("نقطة #${index + 1}", style = MaterialTheme.typography.labelLarge, color = TextPrimary)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                FilterChip(
                                    selected = step.isSwipe,
                                    onClick = { stepsState[index] = step.copy(isSwipe = !step.isSwipe) },
                                    label = { Text(if (step.isSwipe) "سحب" else "نقر", fontSize = 11.sp) }
                                )
                                if (stepsState.size > 1) {
                                    IconButton(
                                        onClick = { stepsState.removeAt(index) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف الخطوة", tint = TacticalRose)
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedTextField(
                                value = step.x,
                                onValueChange = { stepsState[index] = step.copy(x = it.filter { c -> c.isDigit() }) },
                                label = { Text("X") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = step.y,
                                onValueChange = { stepsState[index] = step.copy(y = it.filter { c -> c.isDigit() }) },
                                label = { Text("Y") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = step.delayMs,
                                onValueChange = { stepsState[index] = step.copy(delayMs = it.filter { c -> c.isDigit() }) },
                                label = { Text("تأخير ms") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        if (step.isSwipe) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OutlinedTextField(
                                    value = step.endX,
                                    onValueChange = { stepsState[index] = step.copy(endX = it.filter { c -> c.isDigit() }) },
                                    label = { Text("نهاية X") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = step.endY,
                                    onValueChange = { stepsState[index] = step.copy(endY = it.filter { c -> c.isDigit() }) },
                                    label = { Text("نهاية Y") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val mappedSteps = stepsState.mapIndexed { idx, s ->
                        MacroStepEntity(
                            macroId = existing?.macro?.id ?: 0L,
                            stepIndex = idx,
                            targetX = s.x.toFloatOrNull() ?: 500f,
                            targetY = s.y.toFloatOrNull() ?: 500f,
                            delayBeforeMs = s.delayMs.toLongOrNull() ?: 0L,
                            holdDurationMs = if (s.isSwipe) 160L else if (executionMode == ExecutionMode.MULTI_TOUCH) 60L else 35L,
                            isSwipe = s.isSwipe,
                            endX = s.endX.toFloatOrNull() ?: 920f,
                            endY = s.endY.toFloatOrNull() ?: 520f
                        )
                    }
                    onSave(
                        name.ifBlank { "ماكرو ${profileId}" },
                        triggerMode,
                        voiceKeyword,
                        triggerZoneXText.toFloatOrNull() ?: 260f,
                        triggerZoneYText.toFloatOrNull() ?: 420f,
                        selectedColor,
                        executionMode,
                        repeatCount,
                        gestureTrigger,
                        mappedSteps
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
                modifier = Modifier.testTag("save_macro_dialog_btn")
            ) {
                Text("حفظ الماكرو")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = TextSecondary)
            }
        }
    )
}
