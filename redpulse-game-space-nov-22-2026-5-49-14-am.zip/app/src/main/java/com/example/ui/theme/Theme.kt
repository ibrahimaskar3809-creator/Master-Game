package com.example.ui.theme

import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val RedPulseDarkColorScheme = darkColorScheme(
    primary = NeonRed,
    onPrimary = TextPrimary,
    primaryContainer = NeonRedDim,
    onPrimaryContainer = TextPrimary,
    secondary = CyberCyan,
    onSecondary = ObsidianVoid,
    secondaryContainer = ObsidianElevated,
    onSecondaryContainer = CyberCyan,
    tertiary = TacticalEmerald,
    onTertiary = ObsidianVoid,
    background = ObsidianVoid,
    onBackground = TextPrimary,
    surface = ObsidianSurface,
    onSurface = TextPrimary,
    surfaceVariant = ObsidianCard,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLow = ObsidianSurface,
    surfaceContainer = ObsidianCard,
    surfaceContainerHigh = ObsidianElevated,
    outline = MechaBorder,
    outlineVariant = MechaBorder,
    error = TacticalRose,
    onError = TextPrimary
)

val MechaShapes = Shapes(
    extraSmall = CutCornerShape(topStart = 6.dp, bottomEnd = 6.dp),
    small = CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp),
    medium = CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp),
    large = CutCornerShape(topStart = 18.dp, bottomEnd = 18.dp),
    extraLarge = CutCornerShape(topStart = 24.dp, bottomEnd = 24.dp)
)

@Composable
fun RedPulseTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RedPulseDarkColorScheme,
        typography = RedPulseTypography,
        shapes = MechaShapes,
        content = content
    )
}
