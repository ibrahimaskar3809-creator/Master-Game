package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianVoid = Color(0xFF07080D)
val ObsidianSurface = Color(0xFF0E1118)
val ObsidianCard = Color(0xFF151A24)
val ObsidianElevated = Color(0xFF1C2230)
val MechaBorder = Color(0xFF283042)

val NeonRed = Color(0xFFFF1E2D)
val NeonRedBright = Color(0xFFFF4D5A)
val NeonRedDim = Color(0xFF8C0D17)
val CrimsonGlass = Color(0x33FF1E2D)

val CyberCyan = Color(0xFF00E5FF)
val TacticalEmerald = Color(0xFF00E676)
val TacticalAmber = Color(0xFFFFB300)
val TacticalRose = Color(0xFFFF3B5C)

val TextPrimary = Color(0xFFF3F6FC)
val TextSecondary = Color(0xFF9AA6BD)
val TextMuted = Color(0xFF647087)
