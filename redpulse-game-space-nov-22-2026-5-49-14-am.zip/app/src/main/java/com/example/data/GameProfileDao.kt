package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface GameProfileDao {
    @Transaction
    @Query("SELECT * FROM game_profiles ORDER BY createdAt ASC")
    fun observeAllProfilesWithMacros(): Flow<List<ProfileWithMacros>>

    @Transaction
    @Query("SELECT * FROM game_profiles WHERE isActive = 1 LIMIT 1")
    fun observeActiveProfile(): Flow<ProfileWithMacros?>

    @Query("SELECT COUNT(*) FROM game_profiles")
    suspend fun getProfileCount(): Int

    @Query("SELECT EXISTS(SELECT 1 FROM game_profiles WHERE name = :name)")
    suspend fun existsByName(name: String): Boolean

    @Transaction
    @Query("SELECT * FROM game_profiles WHERE id = :profileId LIMIT 1")
    suspend fun getProfileWithMacros(profileId: Long): ProfileWithMacros?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: GameProfileEntity): Long

    @Update
    suspend fun updateProfile(profile: GameProfileEntity)

    @Query("UPDATE game_profiles SET isActive = CASE WHEN id = :profileId THEN 1 ELSE 0 END")
    suspend fun setActiveProfile(profileId: Long)

    @Query("UPDATE game_profiles SET tapZoneX = :x, tapZoneY = :y WHERE id = :profileId")
    suspend fun updateTapZoneCoordinates(profileId: Long, x: Float, y: Float)

    @Query("UPDATE game_profiles SET sidebarSide = :side WHERE id = :profileId")
    suspend fun updateSidebarSide(profileId: Long, side: String)

    @Query("UPDATE game_profiles SET showCrosshair = :show WHERE id = :profileId")
    suspend fun updateCrosshair(profileId: Long, show: Boolean)

    @Query("DELETE FROM game_profiles WHERE id = :profileId")
    suspend fun deleteProfile(profileId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMacro(macro: MacroBindingEntity): Long

    @Update
    suspend fun updateMacro(macro: MacroBindingEntity)

    @Query("UPDATE macro_bindings SET triggerZoneX = :x, triggerZoneY = :y WHERE id = :macroId")
    suspend fun updateMacroTriggerCoordinates(macroId: Long, x: Float, y: Float)

    @Query("UPDATE macro_bindings SET isEnabled = :enabled WHERE id = :macroId")
    suspend fun setMacroEnabled(macroId: Long, enabled: Boolean)

    @Query("DELETE FROM macro_bindings WHERE id = :macroId")
    suspend fun deleteMacro(macroId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStep(step: MacroStepEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSteps(steps: List<MacroStepEntity>)

    @Update
    suspend fun updateStep(step: MacroStepEntity)

    @Query("UPDATE macro_steps SET targetX = :x, targetY = :y WHERE id = :stepId")
    suspend fun updateStepCoordinates(stepId: Long, x: Float, y: Float)

    @Query("DELETE FROM macro_steps WHERE macroId = :macroId")
    suspend fun deleteStepsForMacro(macroId: Long)

    @Query("DELETE FROM macro_steps WHERE id = :stepId")
    suspend fun deleteStep(stepId: Long)
}
