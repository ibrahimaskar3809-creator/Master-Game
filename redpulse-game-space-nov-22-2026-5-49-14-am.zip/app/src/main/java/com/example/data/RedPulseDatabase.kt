package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        GameProfileEntity::class,
        MacroBindingEntity::class,
        MacroStepEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class RedPulseDatabase : RoomDatabase() {
    abstract fun gameProfileDao(): GameProfileDao

    companion object {
        @Volatile
        private var INSTANCE: RedPulseDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE macro_bindings ADD COLUMN executionMode TEXT NOT NULL DEFAULT 'SEQUENTIAL'"
                )
                db.execSQL(
                    "ALTER TABLE macro_bindings ADD COLUMN repeatCount INTEGER NOT NULL DEFAULT 1"
                )
                db.execSQL(
                    "ALTER TABLE macro_bindings ADD COLUMN gestureTrigger TEXT NOT NULL DEFAULT 'NONE'"
                )
                db.execSQL(
                    "ALTER TABLE macro_steps ADD COLUMN isSwipe INTEGER NOT NULL DEFAULT 0"
                )
                db.execSQL(
                    "ALTER TABLE macro_steps ADD COLUMN endX REAL NOT NULL DEFAULT 0.0"
                )
                db.execSQL(
                    "ALTER TABLE macro_steps ADD COLUMN endY REAL NOT NULL DEFAULT 0.0"
                )
            }
        }

        fun getInstance(context: Context): RedPulseDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    RedPulseDatabase::class.java,
                    "redpulse_gamespace.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
