package com.example.data

import kotlinx.coroutines.flow.Flow

class ProfileRepository(private val dao: GameProfileDao) {

    val allProfiles: Flow<List<ProfileWithMacros>> = dao.observeAllProfilesWithMacros()
    val activeProfile: Flow<ProfileWithMacros?> = dao.observeActiveProfile()

    suspend fun ensureSeeded() {
        if (dao.getProfileCount() > 0) return

        // Profile 1: PUBG Mobile
        val pubgId = dao.insertProfile(
            GameProfileEntity(
                name = "PUBG Mobile",
                genreTag = "Battle Royale",
                isActive = true,
                sidebarSide = SidebarSide.LEFT.name,
                overlayShowVoiceKeyword = "إظهار",
                overlayHideVoiceKeyword = "إخفاء",
                overlayToggleTriggerMode = TriggerMode.BOTH.name,
                tapZoneX = 42f,
                tapZoneY = 380f
            )
        )
        val quickSwitchId = dao.insertMacro(
            MacroBindingEntity(
                profileId = pubgId,
                name = "تبديل سريع",
                triggerMode = TriggerMode.VOICE.name,
                voiceKeyword = "تبديل",
                triggerZoneX = 240f,
                triggerZoneY = 320f,
                accentColorHex = 0xFFFF1E2D,
                sortOrder = 0
            )
        )
        dao.insertSteps(
            listOf(
                MacroStepEntity(macroId = quickSwitchId, stepIndex = 0, targetX = 820f, targetY = 860f, delayBeforeMs = 0L, holdDurationMs = 35L)
            )
        )

        val jumpFireId = dao.insertMacro(
            MacroBindingEntity(
                profileId = pubgId,
                name = "قفز وإطلاق",
                triggerMode = TriggerMode.BOTH.name,
                voiceKeyword = "هجوم",
                triggerZoneX = 240f,
                triggerZoneY = 470f,
                accentColorHex = 0xFF00E5FF,
                sortOrder = 1
            )
        )
        dao.insertSteps(
            listOf(
                MacroStepEntity(macroId = jumpFireId, stepIndex = 0, targetX = 910f, targetY = 640f, delayBeforeMs = 0L, holdDurationMs = 35L),
                MacroStepEntity(macroId = jumpFireId, stepIndex = 1, targetX = 890f, targetY = 480f, delayBeforeMs = 95L, holdDurationMs = 45L)
            )
        )

        // Profile 2: COD Mobile
        val codId = dao.insertProfile(
            GameProfileEntity(
                name = "COD Mobile",
                genreTag = "FPS Arena",
                isActive = false,
                sidebarSide = SidebarSide.RIGHT.name,
                overlayShowVoiceKeyword = "افتح",
                overlayHideVoiceKeyword = "اخفي",
                overlayToggleTriggerMode = TriggerMode.BOTH.name,
                tapZoneX = 940f,
                tapZoneY = 380f
            )
        )
        val reloadId = dao.insertMacro(
            MacroBindingEntity(
                profileId = codId,
                name = "إعادة تعبئة",
                triggerMode = TriggerMode.VOICE.name,
                voiceKeyword = "تعبئة",
                triggerZoneX = 260f,
                triggerZoneY = 360f,
                accentColorHex = 0xFFFFB300,
                sortOrder = 0
            )
        )
        dao.insertSteps(
            listOf(
                MacroStepEntity(macroId = reloadId, stepIndex = 0, targetX = 850f, targetY = 790f, delayBeforeMs = 0L, holdDurationMs = 35L)
            )
        )

        ensureFreeFireProfile(activate = false)
    }

    suspend fun ensureFreeFireProfile(activate: Boolean = true) {
        if (dao.existsByName("Free Fire")) return

        val freeFireId = dao.insertProfile(
            GameProfileEntity(
                name = "Free Fire",
                genreTag = "Battle Royale • Fast Macro",
                isActive = false,
                sidebarSide = SidebarSide.LEFT.name,
                overlayShowVoiceKeyword = "إظهار",
                overlayHideVoiceKeyword = "إخفاء",
                overlayToggleTriggerMode = TriggerMode.BOTH.name,
                tapZoneX = 44f,
                tapZoneY = 340f,
                showCrosshair = true
            )
        )

        // 1. Fast Gloo Wall (Sequential Crouch + Wall deploy sequence, triggered by Voice, Tap, or Swipe Up!)
        val glooWallId = dao.insertMacro(
            MacroBindingEntity(
                profileId = freeFireId,
                name = "ثلجة سريعة (Gloo Wall)",
                triggerMode = TriggerMode.BOTH.name,
                voiceKeyword = "ثلجة",
                triggerZoneX = 230f,
                triggerZoneY = 300f,
                accentColorHex = 0xFF00E5FF,
                sortOrder = 0,
                executionMode = ExecutionMode.SEQUENTIAL.name,
                repeatCount = 1,
                gestureTrigger = GestureTriggerType.SWIPE_UP.name
            )
        )
        dao.insertSteps(
            listOf(
                MacroStepEntity(macroId = glooWallId, stepIndex = 0, targetX = 280f, targetY = 760f, delayBeforeMs = 0L, holdDurationMs = 35L),
                MacroStepEntity(macroId = glooWallId, stepIndex = 1, targetX = 940f, targetY = 820f, delayBeforeMs = 70L, holdDurationMs = 45L)
            )
        )

        // 2. Fast AWM / Weapon Quick Switch (Sequential)
        val awmSwitchId = dao.insertMacro(
            MacroBindingEntity(
                profileId = freeFireId,
                name = "تبديل سلاح (AWM)",
                triggerMode = TriggerMode.BOTH.name,
                voiceKeyword = "تبديل",
                triggerZoneX = 230f,
                triggerZoneY = 410f,
                accentColorHex = 0xFFFF1E2D,
                sortOrder = 1,
                executionMode = ExecutionMode.SEQUENTIAL.name,
                repeatCount = 1,
                gestureTrigger = GestureTriggerType.SWIPE_DOWN.name
            )
        )
        dao.insertSteps(
            listOf(
                MacroStepEntity(macroId = awmSwitchId, stepIndex = 0, targetX = 980f, targetY = 220f, delayBeforeMs = 0L, holdDurationMs = 30L),
                MacroStepEntity(macroId = awmSwitchId, stepIndex = 1, targetX = 920f, targetY = 680f, delayBeforeMs = 65L, holdDurationMs = 40L)
            )
        )

        // 3. Quick Medkit Heal
        val medkitId = dao.insertMacro(
            MacroBindingEntity(
                profileId = freeFireId,
                name = "علاج سريع (Medkit)",
                triggerMode = TriggerMode.BOTH.name,
                voiceKeyword = "علاج",
                triggerZoneX = 230f,
                triggerZoneY = 520f,
                accentColorHex = 0xFF00E676,
                sortOrder = 2,
                executionMode = ExecutionMode.SEQUENTIAL.name,
                repeatCount = 1,
                gestureTrigger = GestureTriggerType.NONE.name
            )
        )
        dao.insertSteps(
            listOf(
                MacroStepEntity(macroId = medkitId, stepIndex = 0, targetX = 170f, targetY = 640f, delayBeforeMs = 0L, holdDurationMs = 35L)
            )
        )

        // 4. Simultaneous Multi-Touch Scope + Fire Macro (2 fingers simultaneously!)
        val scopeFireId = dao.insertMacro(
            MacroBindingEntity(
                profileId = freeFireId,
                name = "سكوب + إطلاق متزامن",
                triggerMode = TriggerMode.BOTH.name,
                voiceKeyword = "سكوب",
                triggerZoneX = 230f,
                triggerZoneY = 630f,
                accentColorHex = 0xFFFFB300,
                sortOrder = 3,
                executionMode = ExecutionMode.MULTI_TOUCH.name,
                repeatCount = 1,
                gestureTrigger = GestureTriggerType.DOUBLE_TAP.name
            )
        )
        dao.insertSteps(
            listOf(
                MacroStepEntity(macroId = scopeFireId, stepIndex = 0, targetX = 1040f, targetY = 480f, delayBeforeMs = 0L, holdDurationMs = 65L),
                MacroStepEntity(macroId = scopeFireId, stepIndex = 1, targetX = 920f, targetY = 680f, delayBeforeMs = 0L, holdDurationMs = 65L)
            )
        )

        if (activate) {
            dao.setActiveProfile(freeFireId)
        }
    }

    suspend fun createProfile(
        name: String,
        genreTag: String,
        sidebarSide: SidebarSide,
        showKeyword: String,
        hideKeyword: String,
        toggleTriggerMode: TriggerMode,
        setActive: Boolean = true
    ): Long {
        val id = dao.insertProfile(
            GameProfileEntity(
                name = name.trim(),
                genreTag = genreTag.trim().ifEmpty { "Gaming" },
                isActive = false,
                sidebarSide = sidebarSide.name,
                overlayShowVoiceKeyword = showKeyword.trim().ifEmpty { "إظهار" },
                overlayHideVoiceKeyword = hideKeyword.trim().ifEmpty { "إخفاء" },
                overlayToggleTriggerMode = toggleTriggerMode.name
            )
        )
        if (setActive) {
            dao.setActiveProfile(id)
        }
        return id
    }

    suspend fun duplicateProfile(source: ProfileWithMacros) {
        val newProfileId = dao.insertProfile(
            source.profile.copy(
                id = 0,
                name = "${source.profile.name} (نسخة)",
                isActive = false,
                createdAt = System.currentTimeMillis()
            )
        )
        source.sortedMacros.forEach { macroWithSteps ->
            val newMacroId = dao.insertMacro(
                macroWithSteps.macro.copy(id = 0, profileId = newProfileId)
            )
            val copiedSteps = macroWithSteps.sortedSteps.map {
                it.copy(id = 0, macroId = newMacroId)
            }
            dao.insertSteps(copiedSteps)
        }
    }

    suspend fun updateProfile(profile: GameProfileEntity) {
        dao.updateProfile(profile)
    }

    suspend fun switchActiveProfile(profileId: Long) {
        dao.setActiveProfile(profileId)
    }

    suspend fun updateTapZoneCoordinates(profileId: Long, x: Float, y: Float) {
        dao.updateTapZoneCoordinates(profileId, x, y)
    }

    suspend fun updateSidebarSide(profileId: Long, side: SidebarSide) {
        dao.updateSidebarSide(profileId, side.name)
    }

    suspend fun updateCrosshair(profileId: Long, show: Boolean) {
        dao.updateCrosshair(profileId, show)
    }

    suspend fun deleteProfile(profileId: Long, fallbackProfileId: Long?) {
        dao.deleteProfile(profileId)
        if (fallbackProfileId != null && fallbackProfileId != profileId) {
            dao.setActiveProfile(fallbackProfileId)
        }
    }

    suspend fun saveMacroWithSteps(
        macro: MacroBindingEntity,
        steps: List<MacroStepEntity>
    ): Long {
        val macroId = if (macro.id == 0L) {
            dao.insertMacro(macro)
        } else {
            dao.updateMacro(macro)
            dao.deleteStepsForMacro(macro.id)
            macro.id
        }
        val indexedSteps = steps.mapIndexed { idx, step ->
            step.copy(id = 0L, macroId = macroId, stepIndex = idx)
        }
        dao.insertSteps(indexedSteps)
        return macroId
    }

    suspend fun updateStepCoordinates(stepId: Long, x: Float, y: Float) {
        dao.updateStepCoordinates(stepId, x, y)
    }

    suspend fun updateMacroTriggerCoordinates(macroId: Long, x: Float, y: Float) {
        dao.updateMacroTriggerCoordinates(macroId, x, y)
    }

    suspend fun setMacroEnabled(macroId: Long, enabled: Boolean) {
        dao.setMacroEnabled(macroId, enabled)
    }

    suspend fun deleteMacro(macroId: Long) {
        dao.deleteMacro(macroId)
    }
}
