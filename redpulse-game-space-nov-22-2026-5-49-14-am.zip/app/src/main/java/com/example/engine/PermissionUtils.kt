package com.example.engine

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.core.content.ContextCompat
import com.example.service.MacroAccessibilityService

data class PermissionStatusSnapshot(
    val overlayGranted: Boolean = false,
    val accessibilityGranted: Boolean = false,
    val microphoneGranted: Boolean = false,
    val notificationsGranted: Boolean = true,
    val dndPolicyGranted: Boolean = false
) {
    val coreReady: Boolean
        get() = overlayGranted && accessibilityGranted

    val allReady: Boolean
        get() = overlayGranted && accessibilityGranted && microphoneGranted && notificationsGranted
}

object PermissionUtils {

    fun checkAll(context: Context): PermissionStatusSnapshot {
        return PermissionStatusSnapshot(
            overlayGranted = hasOverlayPermission(context),
            accessibilityGranted = isAccessibilityEnabled(context),
            microphoneGranted = hasMicrophonePermission(context),
            notificationsGranted = hasNotificationPermission(context),
            dndPolicyGranted = hasDndAccess(context)
        )
    }

    fun hasOverlayPermission(context: Context): Boolean {
        return Settings.canDrawOverlays(context)
    }

    fun hasMicrophonePermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun hasDndAccess(context: Context): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        return nm?.isNotificationPolicyAccessGranted == true
    }

    fun isAccessibilityEnabled(context: Context): Boolean {
        if (MacroAccessibilityService.isConnected.value) return true

        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
        val expectedComponent = ComponentName(context, MacroAccessibilityService::class.java)
        val enabledServices = am?.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        if (enabledServices != null) {
            for (info in enabledServices) {
                val serviceInfo = info.resolveInfo?.serviceInfo ?: continue
                if (serviceInfo.packageName == expectedComponent.packageName &&
                    serviceInfo.name == expectedComponent.className
                ) {
                    return true
                }
            }
        }

        val settingValue = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val flat = expectedComponent.flattenToString()
        val shortFlat = expectedComponent.flattenToShortString()
        return settingValue.split(':').any {
            it.equals(flat, ignoreCase = true) || it.equals(shortFlat, ignoreCase = true)
        }
    }

    fun createOverlayPermissionIntent(context: Context): Intent {
        return Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun createAccessibilitySettingsIntent(): Intent {
        return Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun createDndAccessIntent(): Intent {
        return Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
