package com.example.engine

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VoiceRule(
    val id: String,
    val keyword: String,
    val action: VoiceActionType
)

sealed class VoiceActionType {
    data object ShowOverlay : VoiceActionType()
    data object HideOverlay : VoiceActionType()
    data class ExecuteMacro(val macroId: Long, val macroName: String) : VoiceActionType()
}

object KeywordMatcher {
    private val arabicDiacriticsRegex = Regex("[\\u064B-\\u065F\\u0670]")

    fun normalize(input: String): String {
        return input
            .replace(arabicDiacriticsRegex, "")
            .replace('أ', 'ا')
            .replace('إ', 'ا')
            .replace('آ', 'ا')
            .replace('ة', 'ه')
            .replace('ى', 'ي')
            .lowercase()
            .trim()
    }

    fun findMatch(transcriptCandidates: List<String>, rules: List<VoiceRule>): VoiceRule? {
        if (transcriptCandidates.isEmpty() || rules.isEmpty()) return null
        val normalizedCandidates = transcriptCandidates.map { normalize(it) }.filter { it.isNotEmpty() }
        if (normalizedCandidates.isEmpty()) return null

        // Prefer longer/more specific keywords first
        val sortedRules = rules
            .filter { it.keyword.isNotBlank() }
            .sortedByDescending { it.keyword.length }

        for (rule in sortedRules) {
            val normalizedKey = normalize(rule.keyword)
            if (normalizedKey.isEmpty()) continue
            if (normalizedCandidates.any { candidate -> candidate.contains(normalizedKey) }) {
                return rule
            }
        }
        return null
    }
}

data class VoiceEngineState(
    val isListening: Boolean = false,
    val isAvailable: Boolean = true,
    val lastTranscript: String = "",
    val lastMatchedLabel: String? = null,
    val audioRmsDb: Float = 0f,
    val statusMessage: String = "محرك الأوامر الصوتية جاهز"
)

class VoiceCommandEngine(
    private val context: Context,
    private val onRuleTriggered: (VoiceRule) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var shouldKeepListening = false
    private var activeRules: List<VoiceRule> = emptyList()
    private val lastTriggerTimestamps = mutableMapOf<String, Long>()
    private val commandCooldownMs = 950L

    private val _state = MutableStateFlow(
        VoiceEngineState(isAvailable = SpeechRecognizer.isRecognitionAvailable(context))
    )
    val state: StateFlow<VoiceEngineState> = _state.asStateFlow()

    fun updateRules(rules: List<VoiceRule>) {
        activeRules = rules
    }

    fun startListening() {
        mainHandler.post {
            if (!PermissionUtils.hasMicrophonePermission(context)) {
                shouldKeepListening = false
                _state.value = _state.value.copy(
                    isListening = false,
                    statusMessage = "يرجى منح إذن الميكروفون لتفعيل الأوامر الصوتية"
                )
                return@post
            }
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                shouldKeepListening = false
                _state.value = _state.value.copy(
                    isListening = false,
                    isAvailable = false,
                    statusMessage = "خدمة التعرف الصوتي غير متوفرة على هذا الجهاز"
                )
                return@post
            }

            if (shouldKeepListening && speechRecognizer != null) return@post

            shouldKeepListening = true
            _state.value = _state.value.copy(
                isListening = true,
                isAvailable = true,
                statusMessage = "جاري الاستماع الفوري للأوامر..."
            )
            beginRecognitionSession()
        }
    }

    fun stopListening() {
        mainHandler.post {
            shouldKeepListening = false
            runCatching {
                speechRecognizer?.stopListening()
                speechRecognizer?.cancel()
                speechRecognizer?.destroy()
            }
            speechRecognizer = null
            _state.value = _state.value.copy(
                isListening = false,
                audioRmsDb = 0f,
                statusMessage = "الاستماع متوقف"
            )
        }
    }

    private fun beginRecognitionSession() {
        if (!shouldKeepListening) return

        runCatching {
            speechRecognizer?.destroy()
            val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            recognizer.setRecognitionListener(recognitionListener)
            speechRecognizer = recognizer

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            }
            recognizer.startListening(intent)
        }.onFailure { err ->
            _state.value = _state.value.copy(
                isListening = false,
                statusMessage = "تعذر تشغيل الميكروفون: ${err.localizedMessage ?: "خطأ"}"
            )
            shouldKeepListening = false
        }
    }

    private fun scheduleRestart(delayMs: Long = 160L) {
        if (!shouldKeepListening) return
        mainHandler.postDelayed({
            if (shouldKeepListening) {
                beginRecognitionSession()
            }
        }, delayMs)
    }

    private fun processCandidates(candidates: List<String>) {
        if (candidates.isEmpty()) return
        val primary = candidates.firstOrNull().orEmpty()
        if (primary.isNotBlank()) {
            _state.value = _state.value.copy(lastTranscript = primary)
        }

        val matched = KeywordMatcher.findMatch(candidates, activeRules) ?: return
        val now = SystemClock.elapsedRealtime()
        val lastFired = lastTriggerTimestamps[matched.id] ?: 0L
        if (now - lastFired >= commandCooldownMs) {
            lastTriggerTimestamps[matched.id] = now
            val label = when (val act = matched.action) {
                is VoiceActionType.ShowOverlay -> "إظهار الواجهة (${matched.keyword})"
                is VoiceActionType.HideOverlay -> "إخفاء الواجهة (${matched.keyword})"
                is VoiceActionType.ExecuteMacro -> "${act.macroName} (${matched.keyword})"
            }
            _state.value = _state.value.copy(
                lastMatchedLabel = label,
                statusMessage = "تم تنفيذ: $label"
            )
            onRuleTriggered(matched)
        }
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            _state.value = _state.value.copy(
                isListening = true,
                statusMessage = "نشط - تحدث الآن"
            )
        }

        override fun onBeginningOfSpeech() {}

        override fun onRmsChanged(rmsdB: Float) {
            _state.value = _state.value.copy(audioRmsDb = rmsdB.coerceIn(0f, 12f))
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            if (!shouldKeepListening) return
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    shouldKeepListening = false
                    _state.value = _state.value.copy(
                        isListening = false,
                        statusMessage = "مطلوب إذن الميكروفون"
                    )
                }
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    scheduleRestart(120L)
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    scheduleRestart(350L)
                }
                else -> {
                    _state.value = _state.value.copy(
                        statusMessage = "إعادة ضبط الاستماع..."
                    )
                    scheduleRestart(500L)
                }
            }
        }

        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            processCandidates(matches)
            scheduleRestart(140L)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            processCandidates(matches)
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }
}
