package com.example.engine

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.view.Choreographer
import android.view.Display
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.roundToInt

data class BatteryTelemetry(
    val levelPercent: Int = 100,
    val isCharging: Boolean = false,
    val tempCelsius: Float = 34.0f,
    val voltageMv: Int = 4150
)

data class TelemetrySnapshot(
    val fps: Int = 60,
    val refreshRate: Int = 60,
    val pingMs: Int = 0,
    val isNetworkOnline: Boolean = true,
    val cpuPercent: Int = 24,
    val cpuFreqMhz: Int = 1800,
    val gpuPercent: Int = 18,
    val tempCelsius: Float = 34.5f,
    val batteryPercent: Int = 100,
    val isCharging: Boolean = false,
    val batteryVoltageMv: Int = 4150,
    val ramUsedPercent: Int = 48,
    val fpsHistory: List<Int> = listOf(60, 60, 60, 60, 60, 60, 60, 60)
)

class TelemetryMonitor(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _snapshot = MutableStateFlow(
        TelemetrySnapshot(refreshRate = readDisplayRefreshRate())
    )
    val snapshot: StateFlow<TelemetrySnapshot> = _snapshot.asStateFlow()

    private var frameCount = 0
    private var lastFrameWindowStartNs = 0L
    private var avgFrameIntervalMs = 16.6f
    private var lastFrameTimestampNs = 0L
    private var measuredFps = readDisplayRefreshRate()
    private var isMonitoring = false
    private var telemetryJob: Job? = null
    private var pingJob: Job? = null

    private var lastCpuTimeMs = Process.getElapsedCpuTime()
    private var lastWallTimeMs = SystemClock.elapsedRealtime()
    private var lastPingMs = 0
    private var isOnline = true

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isMonitoring) return

            if (lastFrameWindowStartNs == 0L) {
                lastFrameWindowStartNs = frameTimeNanos
            }
            if (lastFrameTimestampNs != 0L) {
                val deltaMs = (frameTimeNanos - lastFrameTimestampNs) / 1_000_000f
                if (deltaMs in 1f..200f) {
                    avgFrameIntervalMs = avgFrameIntervalMs * 0.8f + deltaMs * 0.2f
                }
            }
            lastFrameTimestampNs = frameTimeNanos
            frameCount++

            val elapsedNs = frameTimeNanos - lastFrameWindowStartNs
            if (elapsedNs >= 500_000_000L) {
                val fps = ((frameCount * 1_000_000_000.0) / elapsedNs).roundToInt()
                val maxRefresh = readDisplayRefreshRate()
                measuredFps = fps.coerceIn(1, maxRefresh)
                frameCount = 0
                lastFrameWindowStartNs = frameTimeNanos
            }

            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    @Synchronized
    fun start() {
        if (isMonitoring) return
        isMonitoring = true
        frameCount = 0
        lastFrameWindowStartNs = 0L
        lastFrameTimestampNs = 0L

        mainHandler.post {
            if (isMonitoring) {
                Choreographer.getInstance().postFrameCallback(frameCallback)
            }
        }

        telemetryJob = scope.launch {
            while (isActive && isMonitoring) {
                val refreshRate = readDisplayRefreshRate()
                val (cpu, cpuMhz) = readCpuStats()
                val gpu = readGpuUtilizationPercent(cpu, refreshRate)
                val battery = readBatteryTelemetry()
                val ram = readRamUsedPercent()
                val currentFps = measuredFps.coerceIn(1, refreshRate)

                val prev = _snapshot.value
                val updatedHistory = (prev.fpsHistory + currentFps).takeLast(20)
                _snapshot.value = TelemetrySnapshot(
                    fps = currentFps,
                    refreshRate = refreshRate,
                    pingMs = lastPingMs,
                    isNetworkOnline = isOnline,
                    cpuPercent = cpu,
                    cpuFreqMhz = cpuMhz,
                    gpuPercent = gpu,
                    tempCelsius = battery.tempCelsius,
                    batteryPercent = battery.levelPercent,
                    isCharging = battery.isCharging,
                    batteryVoltageMv = battery.voltageMv,
                    ramUsedPercent = ram,
                    fpsHistory = updatedHistory
                )
                delay(1000L)
            }
        }

        pingJob = scope.launch(Dispatchers.IO) {
            while (isActive && isMonitoring) {
                val (online, ping) = measureRealPing()
                isOnline = online
                if (ping > 0) {
                    lastPingMs = ping
                } else if (!online) {
                    lastPingMs = -1
                }
                delay(2500L)
            }
        }
    }

    @Synchronized
    fun stop() {
        isMonitoring = false
        telemetryJob?.cancel()
        pingJob?.cancel()
        mainHandler.post {
            runCatching { Choreographer.getInstance().removeFrameCallback(frameCallback) }
        }
    }

    private fun readDisplayRefreshRate(): Int {
        return try {
            val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
            val rate = dm?.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate ?: 60f
            rate.roundToInt().coerceIn(30, 240)
        } catch (_: Exception) {
            60
        }
    }

    private suspend fun measureRealPing(): Pair<Boolean, Int> = withContext(Dispatchers.IO) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNet = cm?.activeNetwork
        val caps = cm?.getNetworkCapabilities(activeNet)
        val hasInternet = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        if (!hasInternet) return@withContext Pair(false, -1)

        val targets = listOf("1.1.1.1" to 443, "8.8.8.8" to 53)
        for ((host, port) in targets) {
            val startNs = SystemClock.elapsedRealtimeNanos()
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(host, port), 1500)
                }
                val rttMs = ((SystemClock.elapsedRealtimeNanos() - startNs) / 1_000_000L)
                    .toInt()
                    .coerceIn(1, 999)
                return@withContext Pair(true, rttMs)
            } catch (_: Exception) {
            }
        }
        Pair(true, -1)
    }

    private fun readCpuStats(): Pair<Int, Int> {
        try {
            val cpuDir = File("/sys/devices/system/cpu")
            val coreDirs = cpuDir.listFiles { f ->
                f.isDirectory && f.name.matches(Regex("cpu\\d+"))
            }
            if (!coreDirs.isNullOrEmpty()) {
                var sumRatio = 0.0
                var peakKhz = 0L
                var validCores = 0
                for (core in coreDirs) {
                    val curFile = File(core, "cpufreq/scaling_cur_freq")
                    val maxFile = File(core, "cpufreq/cpuinfo_max_freq")
                    if (curFile.canRead() && maxFile.canRead()) {
                        val cur = curFile.readText().trim().toLongOrNull() ?: continue
                        val max = maxFile.readText().trim().toLongOrNull() ?: continue
                        if (max > 0) {
                            sumRatio += (cur.toDouble() / max.toDouble()).coerceIn(0.0, 1.0)
                            if (cur > peakKhz) peakKhz = cur
                            validCores++
                        }
                    }
                }
                if (validCores > 0) {
                    val pct = ((sumRatio / validCores) * 100.0).roundToInt().coerceIn(5, 100)
                    val mhz = (peakKhz / 1000L).toInt().coerceIn(300, 4200)
                    return pct to mhz
                }
            }
        } catch (_: Exception) {
        }

        val nowCpu = Process.getElapsedCpuTime()
        val nowWall = SystemClock.elapsedRealtime()
        val wallDelta = (nowWall - lastWallTimeMs).coerceAtLeast(1L)
        val cpuDelta = (nowCpu - lastCpuTimeMs).coerceAtLeast(0L)
        lastCpuTimeMs = nowCpu
        lastWallTimeMs = nowWall
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val processLoad = ((cpuDelta.toFloat() / (wallDelta * cores)) * 100f).roundToInt().coerceIn(8, 95)
        return processLoad to (800 + processLoad * 18)
    }

    private fun readGpuUtilizationPercent(cpuFallback: Int, refreshRate: Int): Int {
        val gpuNodes = listOf(
            "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage",
            "/sys/kernel/gpu/gpu_busy"
        )
        for (path in gpuNodes) {
            try {
                val file = File(path)
                if (file.canRead()) {
                    val raw = file.readText().replace("%", "").trim().toIntOrNull()
                    if (raw != null) return raw.coerceIn(0, 100)
                }
            } catch (_: Exception) {
            }
        }
        val frameBudgetMs = 1000f / refreshRate.toFloat()
        val renderRatio = ((avgFrameIntervalMs / frameBudgetMs) * 38f + cpuFallback * 0.35f)
            .roundToInt()
        return renderRatio.coerceIn(10, 98)
    }

    private fun readBatteryTelemetry(): BatteryTelemetry {
        return try {
            val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, 100) ?: 100
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100)?.coerceAtLeast(1) ?: 100
            val percent = ((level * 100f) / scale).roundToInt().coerceIn(0, 100)
            val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            val tenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 340) ?: 340
            val tempC = (tenths / 10f).coerceIn(15f, 70f)
            val voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 4150) ?: 4150
            BatteryTelemetry(
                levelPercent = percent,
                isCharging = isCharging,
                tempCelsius = tempC,
                voltageMv = voltageMv
            )
        } catch (_: Exception) {
            BatteryTelemetry()
        }
    }

    private fun readRamUsedPercent(): Int {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am?.getMemoryInfo(memInfo)
            if (memInfo.totalMem > 0) {
                val used = memInfo.totalMem - memInfo.availMem
                ((used.toDouble() / memInfo.totalMem.toDouble()) * 100.0).roundToInt().coerceIn(5, 99)
            } else {
                50
            }
        } catch (_: Exception) {
            50
        }
    }
}
