package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.ProfileRepository
import com.example.data.RedPulseDatabase
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("RedPulse", appName)
    }

    @Test
    fun `repository seeds default profiles and switches active profile`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, RedPulseDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val repo = ProfileRepository(db.gameProfileDao())
            repo.ensureSeeded()

            val all = repo.allProfiles.first()
            assertTrue(all.size >= 3)
            val freeFire = all.firstOrNull { it.profile.name == "Free Fire" }
            assertNotNull(freeFire)
            assertEquals(4, freeFire?.macros?.size)
            assertTrue(freeFire?.profile?.showCrosshair == true)
            assertTrue(freeFire?.macros?.any { it.macro.executionMode == "MULTI_TOUCH" && it.macro.gestureTrigger == "DOUBLE_TAP" } == true)
            val active = repo.activeProfile.first()
            assertNotNull(active)
            assertEquals("PUBG Mobile", active?.profile?.name)

            val ffId = freeFire!!.profile.id
            repo.switchActiveProfile(ffId)
            val switched = repo.activeProfile.first()
            assertEquals(ffId, switched?.profile?.id)
        } finally {
            db.close()
        }
    }
}
