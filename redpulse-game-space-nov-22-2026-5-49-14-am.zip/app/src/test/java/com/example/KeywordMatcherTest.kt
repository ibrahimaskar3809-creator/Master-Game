package com.example

import com.example.engine.KeywordMatcher
import com.example.engine.VoiceActionType
import com.example.engine.VoiceRule
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class KeywordMatcherTest {

    private val sampleRules = listOf(
        VoiceRule("show", "إظهار", VoiceActionType.ShowOverlay),
        VoiceRule("hide", "إخفاء", VoiceActionType.HideOverlay),
        VoiceRule("m1", "تبديل", VoiceActionType.ExecuteMacro(1L, "تبديل سريع")),
        VoiceRule("m2", "reload", VoiceActionType.ExecuteMacro(2L, "Reload"))
    )

    @Test
    fun arabicAlefAndTashkeelNormalization_matchesCorrectly() {
        val match = KeywordMatcher.findMatch(listOf("اِظهار القائمة الآن"), sampleRules)
        assertNotNull(match)
        assertEquals("show", match?.id)
    }

    @Test
    fun arabicHideCommand_matchesWithoutHamza() {
        val match = KeywordMatcher.findMatch(listOf("اخفاء الشاشة"), sampleRules)
        assertNotNull(match)
        assertEquals("hide", match?.id)
    }

    @Test
    fun englishCommand_matchesCaseInsensitive() {
        val match = KeywordMatcher.findMatch(listOf("Quick RELOAD weapon"), sampleRules)
        assertNotNull(match)
        assertEquals("m2", match?.id)
    }

    @Test
    fun unrelatedSpeech_returnsNull() {
        val match = KeywordMatcher.findMatch(listOf("مرحبا بكم في اللعبة"), sampleRules)
        assertNull(match)
    }
}
