package com.example.data

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

enum class TriggerMode(val labelAr: String) {
    VOICE("أمر صوتي محدد"),
    TAP_POINT("نقطة نقر محددة"),
    BOTH("صوتي + نقطة نقر");

    companion object {
        fun fromString(value: String): TriggerMode =
            entries.firstOrNull { it.name == value } ?: VOICE
    }
}

enum class SidebarSide(val labelAr: String) {
    LEFT("اليسار"),
    RIGHT("اليمين");

    companion object {
        fun fromString(value: String): SidebarSide =
            entries.firstOrNull { it.name == value } ?: LEFT
    }
}

@Entity(tableName = "game_profiles")
data class GameProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val genreTag: String = "Tactical",
    val isActive: Boolean = false,
    val sidebarSide: String = SidebarSide.LEFT.name,
    val overlayShowVoiceKeyword: String = "إظهار",
    val overlayHideVoiceKeyword: String = "إخفاء",
    val overlayToggleTriggerMode: String = TriggerMode.BOTH.name,
    val tapZoneX: Float = 48f,
    val tapZoneY: Float = 360f,
    val showCrosshair: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "macro_bindings",
    foreignKeys = [
        ForeignKey(
            entity = GameProfileEntity::class,
            parentColumns = ["id"],
            childColumns = ["profileId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("profileId")]
)
data class MacroBindingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: Long,
    val name: String,
    val triggerMode: String = TriggerMode.VOICE.name,
    val voiceKeyword: String = "",
    val triggerZoneX: Float = 220f,
    val triggerZoneY: Float = 420f,
    val isEnabled: Boolean = true,
    val accentColorHex: Long = 0xFFFF1E2D,
    val sortOrder: Int = 0
)

@Entity(
    tableName = "macro_steps",
    foreignKeys = [
        ForeignKey(
            entity = MacroBindingEntity::class,
            parentColumns = ["id"],
            childColumns = ["macroId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("macroId")]
)
data class MacroStepEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val macroId: Long,
    val stepIndex: Int,
    val targetX: Float,
    val targetY: Float,
    val delayBeforeMs: Long = 0L,
    val holdDurationMs: Long = 35L
)

data class MacroWithSteps(
    @Embedded val macro: MacroBindingEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "macroId"
    )
    val steps: List<MacroStepEntity>
) {
    val sortedSteps: List<MacroStepEntity>
        get() = steps.sortedBy { it.stepIndex }
}

data class ProfileWithMacros(
    @Embedded val profile: GameProfileEntity,
    @Relation(
        entity = MacroBindingEntity::class,
        parentColumn = "id",
        entityColumn = "profileId"
    )
    val macros: List<MacroWithSteps>
) {
    val sortedMacros: List<MacroWithSteps>
        get() = macros.sortedBy { it.macro.sortOrder }
}
