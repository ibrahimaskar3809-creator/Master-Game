package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        GameProfileEntity::class,
        MacroBindingEntity::class,
        MacroStepEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class RedPulseDatabase : RoomDatabase() {
    abstract fun gameProfileDao(): GameProfileDao

    companion object {
        @Volatile
        private var INSTANCE: RedPulseDatabase? = null

        fun getInstance(context: Context): RedPulseDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    RedPulseDatabase::class.java,
                    "redpulse_gamespace.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
