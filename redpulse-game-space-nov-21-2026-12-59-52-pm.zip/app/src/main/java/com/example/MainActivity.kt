package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.FolderSpecial
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.engine.PermissionUtils
import com.example.ui.DashboardScreen
import com.example.ui.MacroStudioScreen
import com.example.ui.MainViewModel
import com.example.ui.ProfilesScreen
import com.example.ui.theme.CrimsonGlass
import com.example.ui.theme.NeonRedBright
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.RedPulseTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

private data class NavTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val MAIN_TABS = listOf(
    NavTab("dashboard", "لوحة التحكم", Icons.Filled.Dashboard, Icons.Outlined.Dashboard, "tab_dashboard"),
    NavTab("macros", "الماكرو والصوت", Icons.Filled.TouchApp, Icons.Outlined.TouchApp, "tab_macros"),
    NavTab("profiles", "الملفات", Icons.Filled.FolderSpecial, Icons.Outlined.FolderSpecial, "tab_profiles")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(ObsidianVoid.toArgb()),
            navigationBarStyle = SystemBarStyle.dark(ObsidianSurface.toArgb())
        )
        setContent {
            RedPulseTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    RedPulseRoot()
                }
            }
        }
    }
}

@Composable
fun RedPulseRoot(viewModel: MainViewModel = viewModel()) {
    val context = LocalContext.current
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }

    val allProfiles by viewModel.allProfiles.collectAsStateWithLifecycle()
    val activeProfile by viewModel.activeProfile.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val voiceState by viewModel.voiceState.collectAsStateWithLifecycle()
    val overlayState by viewModel.overlayState.collectAsStateWithLifecycle()
    val permissions by viewModel.permissions.collectAsStateWithLifecycle()
    val isAccessibilityConnected by viewModel.accessibilityConnected.collectAsStateWithLifecycle()

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        viewModel.refreshPermissions()
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        viewModel.refreshPermissions()
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.refreshPermissions()
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianVoid)
    ) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = ObsidianVoid,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = ObsidianSurface,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        MAIN_TABS.forEachIndexed { index, tab ->
                            val selected = selectedTab == index
                            NavigationBarItem(
                                selected = selected,
                                onClick = { selectedTab = index },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = NeonRedBright,
                                    selectedTextColor = TextPrimary,
                                    indicatorColor = CrimsonGlass,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted
                                ),
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(
                        containerColor = ObsidianSurface
                    ) {
                        MAIN_TABS.forEachIndexed { index, tab ->
                            val selected = selectedTab == index
                            NavigationRailItem(
                                selected = selected,
                                onClick = { selectedTab = index },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = NeonRedBright,
                                    selectedTextColor = TextPrimary,
                                    indicatorColor = CrimsonGlass,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted
                                ),
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }

                val accessibilityReady = permissions.accessibilityGranted || isAccessibilityConnected

                when (selectedTab) {
                    0 -> DashboardScreen(
                        activeProfile = activeProfile,
                        telemetry = telemetry,
                        overlayState = overlayState,
                        permissions = permissions.copy(accessibilityGranted = accessibilityReady),
                        onRequestOverlayPermission = {
                            context.startActivity(PermissionUtils.createOverlayPermissionIntent(context))
                        },
                        onOpenAccessibilitySettings = {
                            context.startActivity(PermissionUtils.createAccessibilitySettingsIntent())
                        },
                        onRequestMicPermission = {
                            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        onRequestNotificationPermission = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        },
                        onStartOverlay = { viewModel.startOverlay() },
                        onStopOverlay = { viewModel.stopOverlay() },
                        onChangeVisibilityMode = { viewModel.setOverlayVisibility(it) },
                        onToggleEditPoints = { viewModel.toggleEditPoints() },
                        onSaveOverlayConfig = { showKey, hideKey, mode, side, crosshair ->
                            viewModel.updateActiveProfileOverlayConfig(
                                showKeyword = showKey,
                                hideKeyword = hideKey,
                                toggleMode = mode,
                                sidebarSide = side,
                                showCrosshair = crosshair
                            )
                        }
                    )
                    1 -> MacroStudioScreen(
                        activeProfile = activeProfile,
                        voiceState = voiceState,
                        isAccessibilityReady = accessibilityReady,
                        isOverlayRunning = overlayState.isServiceRunning,
                        onToggleVoice = {
                            if (permissions.microphoneGranted) {
                                viewModel.toggleVoiceListening()
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        onOpenFloatingPointEditor = {
                            viewModel.setOverlayVisibility(OverlayVisibilityMode.SIDEBAR_EXPANDED)
                            if (!overlayState.isEditingPoints) {
                                viewModel.toggleEditPoints()
                            }
                        },
                        onSaveMacro = { existing, profId, name, mode, keyword, trigX, trigY, colorHex, steps ->
                            viewModel.saveMacro(
                                existingMacro = existing,
                                profileId = profId,
                                name = name,
                                triggerMode = mode,
                                voiceKeyword = keyword,
                                triggerZoneX = trigX,
                                triggerZoneY = trigY,
                                accentColorHex = colorHex,
                                steps = steps
                            )
                        },
                        onToggleMacroEnabled = { macroId, enabled ->
                            viewModel.setMacroEnabled(macroId, enabled)
                        },
                        onDeleteMacro = { macroId ->
                            viewModel.deleteMacro(macroId)
                        },
                        onTestMacro = { macroId ->
                            viewModel.testExecuteMacro(macroId)
                        }
                    )
                    else -> ProfilesScreen(
                        profiles = allProfiles,
                        onSwitchProfile = { viewModel.switchProfile(it) },
                        onCreateProfile = { name, genre, side, showKey, hideKey, mode ->
                            viewModel.createProfile(name, genre, side, showKey, hideKey, mode)
                        },
                        onDuplicateProfile = { viewModel.duplicateProfile(it) },
                        onDeleteProfile = { viewModel.deleteProfile(it) }
                    )
                }
            }
        }
    }
}
