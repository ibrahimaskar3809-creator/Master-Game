package com.example

import android.app.Application
import android.content.Intent
import android.os.Build
import com.example.data.ProfileRepository
import com.example.data.ProfileWithMacros
import com.example.data.RedPulseDatabase
import com.example.data.TriggerMode
import com.example.engine.TelemetryMonitor
import com.example.engine.VoiceActionType
import com.example.engine.VoiceCommandEngine
import com.example.engine.VoiceRule
import com.example.service.MacroAccessibilityService
import com.example.service.OverlayForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class OverlayVisibilityMode {
    SIDEBAR_EXPANDED,
    EDGE_PILL,
    FULL_HIDE_MODE
}

data class OverlayRuntimeState(
    val isServiceRunning: Boolean = false,
    val visibilityMode: OverlayVisibilityMode = OverlayVisibilityMode.SIDEBAR_EXPANDED,
    val isEditingPoints: Boolean = false,
    val isDndActive: Boolean = false,
    val lastStatusMessage: String? = null
)

class RedPulseApp : Application() {

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    val database by lazy { RedPulseDatabase.getInstance(this) }
    val repository by lazy { ProfileRepository(database.gameProfileDao()) }
    val telemetryMonitor by lazy { TelemetryMonitor(this) }

    lateinit var activeProfileFlow: StateFlow<ProfileWithMacros?>
        private set

    lateinit var voiceCommandEngine: VoiceCommandEngine
        private set

    private val _overlayState = MutableStateFlow(OverlayRuntimeState())
    val overlayState: StateFlow<OverlayRuntimeState> = _overlayState.asStateFlow()

    override fun onCreate() {
        super.onCreate()

        appScope.launch(Dispatchers.IO) {
            repository.ensureSeeded()
        }

        activeProfileFlow = repository.activeProfile.stateIn(
            scope = appScope,
            started = SharingStarted.Eagerly,
            initialValue = null
        )

        voiceCommandEngine = VoiceCommandEngine(this) { rule ->
            handleVoiceRuleTriggered(rule)
        }

        appScope.launch {
            activeProfileFlow.collect { profileWithMacros ->
                syncVoiceRules(profileWithMacros)
            }
        }

        telemetryMonitor.start()
    }

    private fun syncVoiceRules(profileWithMacros: ProfileWithMacros?) {
        if (profileWithMacros == null) {
            voiceCommandEngine.updateRules(emptyList())
            return
        }
        val profile = profileWithMacros.profile
        val toggleMode = TriggerMode.fromString(profile.overlayToggleTriggerMode)
        val rules = mutableListOf<VoiceRule>()

        if (toggleMode == TriggerMode.VOICE || toggleMode == TriggerMode.BOTH) {
            if (profile.overlayShowVoiceKeyword.isNotBlank()) {
                rules += VoiceRule(
                    id = "overlay_show",
                    keyword = profile.overlayShowVoiceKeyword,
                    action = VoiceActionType.ShowOverlay
                )
            }
            if (profile.overlayHideVoiceKeyword.isNotBlank()) {
                rules += VoiceRule(
                    id = "overlay_hide",
                    keyword = profile.overlayHideVoiceKeyword,
                    action = VoiceActionType.HideOverlay
                )
            }
        }

        profileWithMacros.sortedMacros
            .filter { it.macro.isEnabled }
            .forEach { macroWithSteps ->
                val mode = TriggerMode.fromString(macroWithSteps.macro.triggerMode)
                if ((mode == TriggerMode.VOICE || mode == TriggerMode.BOTH) &&
                    macroWithSteps.macro.voiceKeyword.isNotBlank()
                ) {
                    rules += VoiceRule(
                        id = "macro_${macroWithSteps.macro.id}",
                        keyword = macroWithSteps.macro.voiceKeyword,
                        action = VoiceActionType.ExecuteMacro(
                            macroId = macroWithSteps.macro.id,
                            macroName = macroWithSteps.macro.name
                        )
                    )
                }
            }

        voiceCommandEngine.updateRules(rules)
    }

    private fun handleVoiceRuleTriggered(rule: VoiceRule) {
        when (val action = rule.action) {
            is VoiceActionType.ShowOverlay -> {
                updateOverlayState {
                    it.copy(
                        visibilityMode = OverlayVisibilityMode.SIDEBAR_EXPANDED,
                        lastStatusMessage = "تم إظهار الواجهة عبر الصوت"
                    )
                }
            }
            is VoiceActionType.HideOverlay -> {
                updateOverlayState {
                    it.copy(
                        visibilityMode = OverlayVisibilityMode.FULL_HIDE_MODE,
                        isEditingPoints = false,
                        lastStatusMessage = "وضع الإخفاء الكامل نشط"
                    )
                }
            }
            is VoiceActionType.ExecuteMacro -> {
                executeMacroById(action.macroId)
            }
        }
    }

    fun executeMacroById(macroId: Long): Boolean {
        val macroWithSteps = activeProfileFlow.value
            ?.macros
            ?.firstOrNull { it.macro.id == macroId }
            ?: return false
        if (!macroWithSteps.macro.isEnabled || macroWithSteps.steps.isEmpty()) return false

        val ok = MacroAccessibilityService.dispatchMacro(
            macroName = macroWithSteps.macro.name,
            steps = macroWithSteps.sortedSteps
        )
        updateOverlayState {
            it.copy(
                lastStatusMessage = if (ok) {
                    "تم تنفيذ: ${macroWithSteps.macro.name}"
                } else {
                    "فعّل خدمة الوصول لتنفيذ اللمس"
                }
            )
        }
        return ok
    }

    fun startOverlayService() {
        val intent = Intent(this, OverlayForegroundService::class.java).apply {
            action = OverlayForegroundService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    fun stopOverlayService() {
        val intent = Intent(this, OverlayForegroundService::class.java).apply {
            action = OverlayForegroundService.ACTION_STOP
        }
        startService(intent)
    }

    fun updateOverlayState(transform: (OverlayRuntimeState) -> OverlayRuntimeState) {
        _overlayState.value = transform(_overlayState.value)
    }
}
