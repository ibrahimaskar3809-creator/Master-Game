package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.MainActivity
import com.example.OverlayVisibilityMode
import com.example.R
import com.example.RedPulseApp
import com.example.data.ProfileWithMacros
import com.example.data.SidebarSide
import com.example.data.TriggerMode
import com.example.engine.PermissionUtils
import com.example.overlay.DraggableTargetReticleUi
import com.example.overlay.FloatingEdgePillUi
import com.example.overlay.GesturePulseRingUi
import com.example.overlay.HideToggleZoneUi
import com.example.overlay.OverlaySidebarUi
import com.example.overlay.TacticalCrosshairUi
import com.example.overlay.TapPointTriggerButtonUi
import com.example.ui.theme.RedPulseTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class OverlayForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var windowManager: WindowManager
    private lateinit var app: RedPulseApp

    private data class WindowEntry(
        val view: View,
        val params: WindowManager.LayoutParams,
        val lifecycleOwner: OverlayLifecycleOwner
    )

    private var sidebarWindow: WindowEntry? = null
    private var edgePillWindow: WindowEntry? = null
    private var hideZoneWindow: WindowEntry? = null
    private var crosshairWindow: WindowEntry? = null
    private val macroNodeWindows = mutableMapOf<String, WindowEntry>()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var lastNodeRenderKey: String = ""

    override fun onCreate() {
        super.onCreate()
        app = application as RedPulseApp
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        createNotificationChannel()
        startForegroundCompat()

        if (!PermissionUtils.hasOverlayPermission(this)) {
            stopSelf()
            return
        }

        app.updateOverlayState {
            it.copy(
                isServiceRunning = true,
                visibilityMode = OverlayVisibilityMode.SIDEBAR_EXPANDED
            )
        }

        observeStateAndRenderWindows()
        observePulseFeedback()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                app.voiceCommandEngine.stopListening()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_VISIBILITY -> {
                val current = app.overlayState.value.visibilityMode
                val next = if (current == OverlayVisibilityMode.SIDEBAR_EXPANDED) {
                    OverlayVisibilityMode.FULL_HIDE_MODE
                } else {
                    OverlayVisibilityMode.SIDEBAR_EXPANDED
                }
                app.updateOverlayState { it.copy(visibilityMode = next, isEditingPoints = false) }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        clearAllWindows()
        app.updateOverlayState {
            it.copy(isServiceRunning = false, isEditingPoints = false)
        }
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val type = if (PermissionUtils.hasMicrophonePermission(this)) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            }
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val toggleIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, OverlayForegroundService::class.java).apply {
                action = ACTION_TOGGLE_VISIBILITY
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, OverlayForegroundService::class.java).apply {
                action = ACTION_STOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .addAction(0, "إظهار/إخفاء", toggleIntent)
            .addAction(0, "إيقاف", stopIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.overlay_notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun observeStateAndRenderWindows() {
        serviceScope.launch {
            combine(
                app.overlayState,
                app.activeProfileFlow
            ) { runtime, activeProfile ->
                runtime to activeProfile
            }.collect { (runtime, activeProfile) ->
                if (!PermissionUtils.hasOverlayPermission(this@OverlayForegroundService)) {
                    stopSelf()
                    return@collect
                }
                syncOverlayWindows(runtime.visibilityMode, runtime.isEditingPoints, activeProfile)
            }
        }
    }

    private fun observePulseFeedback() {
        serviceScope.launch {
            MacroAccessibilityService.pulseEvents.collect { pulse ->
                showTemporaryPulseAt(pulse.x, pulse.y, pulse.timestampMs)
            }
        }
    }

    private fun syncOverlayWindows(
        visibilityMode: OverlayVisibilityMode,
        isEditingPoints: Boolean,
        activeProfile: ProfileWithMacros?
    ) {
        val profile = activeProfile?.profile
        val side = SidebarSide.fromString(profile?.sidebarSide ?: SidebarSide.LEFT.name)

        // 1. Sidebar vs Edge Pill
        when (visibilityMode) {
            OverlayVisibilityMode.SIDEBAR_EXPANDED -> {
                removeWindow(edgePillWindow)
                edgePillWindow = null
                ensureSidebarWindow(side)
            }
            OverlayVisibilityMode.EDGE_PILL -> {
                removeWindow(sidebarWindow)
                sidebarWindow = null
                ensureEdgePillWindow(side)
            }
            OverlayVisibilityMode.FULL_HIDE_MODE -> {
                removeWindow(sidebarWindow)
                sidebarWindow = null
                removeWindow(edgePillWindow)
                edgePillWindow = null
            }
        }

        // 2. Tactical Crosshair
        if (profile?.showCrosshair == true) {
            ensureCrosshairWindow()
        } else {
            removeWindow(crosshairWindow)
            crosshairWindow = null
        }

        // 3. Hide/Show Custom Tap Zone
        val toggleMode = TriggerMode.fromString(profile?.overlayToggleTriggerMode ?: TriggerMode.BOTH.name)
        val shouldShowHideZone = profile != null &&
            (toggleMode == TriggerMode.TAP_POINT || toggleMode == TriggerMode.BOTH) &&
            (isEditingPoints || visibilityMode == OverlayVisibilityMode.FULL_HIDE_MODE)

        if (shouldShowHideZone) {
            ensureHideZoneWindow(profile!!.id, profile.tapZoneX, profile.tapZoneY, isEditingPoints, visibilityMode)
        } else {
            removeWindow(hideZoneWindow)
            hideZoneWindow = null
        }

        // 4. Macro Target Points (when editing) & Tap-Point Trigger Buttons (when active)
        syncMacroNodeWindows(visibilityMode, isEditingPoints, activeProfile)
    }

    private fun createOverlayParams(
        width: Int = WindowManager.LayoutParams.WRAP_CONTENT,
        height: Int = WindowManager.LayoutParams.WRAP_CONTENT,
        gravity: Int = Gravity.TOP or Gravity.START,
        x: Int = 0,
        y: Int = 0,
        touchable: Boolean = true
    ): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (!touchable) {
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        return WindowManager.LayoutParams(width, height, type, flags, PixelFormat.TRANSLUCENT).apply {
            this.gravity = gravity
            this.x = x
            this.y = y
        }
    }

    private fun addComposeWindow(
        params: WindowManager.LayoutParams,
        content: @androidx.compose.runtime.Composable () -> Unit
    ): WindowEntry {
        val lifecycleOwner = OverlayLifecycleOwner().apply { performCreate() }
        val composeView = ComposeView(this).apply {
            lifecycleOwner.attachToView(this)
            setContent {
                RedPulseTheme {
                    content()
                }
            }
        }
        windowManager.addView(composeView, params)
        return WindowEntry(composeView, params, lifecycleOwner)
    }

    private fun removeWindow(entry: WindowEntry?) {
        if (entry == null) return
        runCatching { windowManager.removeView(entry.view) }
        entry.lifecycleOwner.performDestroy()
    }

    private fun ensureSidebarWindow(side: SidebarSide) {
        val desiredGravity = Gravity.CENTER_VERTICAL or if (side == SidebarSide.LEFT) Gravity.START else Gravity.END
        val existing = sidebarWindow
        if (existing != null) {
            if (existing.params.gravity != desiredGravity) {
                existing.params.gravity = desiredGravity
                runCatching { windowManager.updateViewLayout(existing.view, existing.params) }
            }
            return
        }

        val params = createOverlayParams(
            gravity = desiredGravity,
            x = dpToPx(8),
            y = 0
        )
        sidebarWindow = addComposeWindow(params) {
            val telemetry by app.telemetryMonitor.snapshot.collectAsState()
            val voiceState by app.voiceCommandEngine.state.collectAsState()
            val runtime by app.overlayState.collectAsState()
            val activeProfile by app.activeProfileFlow.collectAsState()
            val allProfiles by app.repository.allProfiles.collectAsState(initial = emptyList())
            val isAccessibilityReady by MacroAccessibilityService.isConnected.collectAsState()

            OverlaySidebarUi(
                telemetry = telemetry,
                voiceState = voiceState,
                runtimeState = runtime,
                activeProfile = activeProfile,
                allProfiles = allProfiles,
                isAccessibilityReady = isAccessibilityReady,
                onCollapseToPill = {
                    app.updateOverlayState {
                        it.copy(visibilityMode = OverlayVisibilityMode.EDGE_PILL, isEditingPoints = false)
                    }
                },
                onEnterHideMode = {
                    app.updateOverlayState {
                        it.copy(
                            visibilityMode = OverlayVisibilityMode.FULL_HIDE_MODE,
                            isEditingPoints = false,
                            lastStatusMessage = "وضع الإخفاء الكامل نشط"
                        )
                    }
                },
                onStopOverlay = {
                    app.voiceCommandEngine.stopListening()
                    stopSelf()
                },
                onToggleVoice = {
                    if (app.voiceCommandEngine.state.value.isListening) {
                        app.voiceCommandEngine.stopListening()
                    } else {
                        startForegroundCompat()
                        app.voiceCommandEngine.startListening()
                    }
                },
                onToggleEditPoints = {
                    app.updateOverlayState {
                        it.copy(isEditingPoints = !it.isEditingPoints)
                    }
                },
                onFlipSidebarSide = {
                    val profile = activeProfile?.profile ?: return@OverlaySidebarUi
                    val nextSide = if (SidebarSide.fromString(profile.sidebarSide) == SidebarSide.LEFT) {
                        SidebarSide.RIGHT
                    } else {
                        SidebarSide.LEFT
                    }
                    serviceScope.launch(Dispatchers.IO) {
                        app.repository.updateSidebarSide(profile.id, nextSide)
                    }
                },
                onToggleCrosshair = {
                    val profile = activeProfile?.profile ?: return@OverlaySidebarUi
                    serviceScope.launch(Dispatchers.IO) {
                        app.repository.updateCrosshair(profile.id, !profile.showCrosshair)
                    }
                },
                onToggleDnd = {
                    toggleDndMode()
                },
                onSelectProfile = { profileId ->
                    serviceScope.launch(Dispatchers.IO) {
                        app.repository.switchActiveProfile(profileId)
                    }
                },
                onExecuteMacro = { macroId ->
                    app.executeMacroById(macroId)
                },
                onToggleMacroEnabled = { macroId, enabled ->
                    serviceScope.launch(Dispatchers.IO) {
                        app.repository.setMacroEnabled(macroId, enabled)
                    }
                }
            )
        }
    }

    private fun ensureEdgePillWindow(side: SidebarSide) {
        val desiredGravity = Gravity.CENTER_VERTICAL or if (side == SidebarSide.LEFT) Gravity.START else Gravity.END
        val existing = edgePillWindow
        if (existing != null) {
            if (existing.params.gravity != desiredGravity) {
                existing.params.gravity = desiredGravity
                runCatching { windowManager.updateViewLayout(existing.view, existing.params) }
            }
            return
        }

        val params = createOverlayParams(gravity = desiredGravity, x = 0, y = 0)
        edgePillWindow = addComposeWindow(params) {
            val activeProfile by app.activeProfileFlow.collectAsState()
            val currentSide = SidebarSide.fromString(activeProfile?.profile?.sidebarSide ?: SidebarSide.LEFT.name)
            FloatingEdgePillUi(
                side = currentSide,
                onExpand = {
                    app.updateOverlayState { it.copy(visibilityMode = OverlayVisibilityMode.SIDEBAR_EXPANDED) }
                },
                onDragVertical = { deltaY ->
                    edgePillWindow?.let { entry ->
                        entry.params.y = (entry.params.y + deltaY.roundToInt()).coerceIn(-600, 600)
                        runCatching { windowManager.updateViewLayout(entry.view, entry.params) }
                    }
                }
            )
        }
    }

    private fun ensureCrosshairWindow() {
        if (crosshairWindow != null) return
        val params = createOverlayParams(
            gravity = Gravity.CENTER,
            x = 0,
            y = 0,
            touchable = false
        )
        crosshairWindow = addComposeWindow(params) {
            TacticalCrosshairUi()
        }
    }

    private fun ensureHideZoneWindow(
        profileId: Long,
        tapX: Float,
        tapY: Float,
        isEditing: Boolean,
        visibilityMode: OverlayVisibilityMode
    ) {
        val halfPx = dpToPx(24)
        val existing = hideZoneWindow
        if (existing != null) {
            if (!isEditing) {
                existing.params.x = (tapX.roundToInt() - halfPx).coerceAtLeast(0)
                existing.params.y = (tapY.roundToInt() - halfPx).coerceAtLeast(0)
                runCatching { windowManager.updateViewLayout(existing.view, existing.params) }
            }
            return
        }

        val params = createOverlayParams(
            gravity = Gravity.TOP or Gravity.START,
            x = (tapX.roundToInt() - halfPx).coerceAtLeast(0),
            y = (tapY.roundToInt() - halfPx).coerceAtLeast(0)
        )
        hideZoneWindow = addComposeWindow(params) {
            val runtime by app.overlayState.collectAsState()
            val activeProfile by app.activeProfileFlow.collectAsState()
            val curProfile = activeProfile?.profile
            val curX = (hideZoneWindow?.params?.x ?: 0) + halfPx
            val curY = (hideZoneWindow?.params?.y ?: 0) + halfPx

            HideToggleZoneUi(
                isEditing = runtime.isEditingPoints,
                isFullHideMode = runtime.visibilityMode == OverlayVisibilityMode.FULL_HIDE_MODE,
                coordX = curProfile?.tapZoneX?.roundToInt() ?: curX,
                coordY = curProfile?.tapZoneY?.roundToInt() ?: curY,
                onToggleOverlay = {
                    app.updateOverlayState {
                        val next = if (it.visibilityMode == OverlayVisibilityMode.FULL_HIDE_MODE) {
                            OverlayVisibilityMode.SIDEBAR_EXPANDED
                        } else {
                            OverlayVisibilityMode.FULL_HIDE_MODE
                        }
                        it.copy(visibilityMode = next, isEditingPoints = false)
                    }
                },
                onDragDelta = { dx, dy ->
                    hideZoneWindow?.let { entry ->
                        val (maxW, maxH) = screenBoundsPx()
                        entry.params.x = (entry.params.x + dx.roundToInt()).coerceIn(0, maxW - halfPx)
                        entry.params.y = (entry.params.y + dy.roundToInt()).coerceIn(0, maxH - halfPx)
                        runCatching { windowManager.updateViewLayout(entry.view, entry.params) }
                    }
                },
                onDragEnd = {
                    val entry = hideZoneWindow ?: return@HideToggleZoneUi
                    val centerX = (entry.params.x + halfPx).toFloat()
                    val centerY = (entry.params.y + halfPx).toFloat()
                    serviceScope.launch(Dispatchers.IO) {
                        app.repository.updateTapZoneCoordinates(profileId, centerX, centerY)
                    }
                }
            )
        }
    }

    private fun syncMacroNodeWindows(
        visibilityMode: OverlayVisibilityMode,
        isEditingPoints: Boolean,
        activeProfile: ProfileWithMacros?
    ) {
        val macros = activeProfile?.sortedMacros.orEmpty()
        val keyBuilder = StringBuilder()
            .append(activeProfile?.profile?.id)
            .append('|').append(visibilityMode.name)
            .append('|').append(isEditingPoints)
        macros.forEach { m ->
            keyBuilder.append('|').append(m.macro.id).append(':').append(m.macro.isEnabled)
                .append(':').append(m.macro.triggerMode)
            m.sortedSteps.forEach { s ->
                keyBuilder.append('#').append(s.id)
            }
        }
        val nextKey = keyBuilder.toString()

        if (nextKey == lastNodeRenderKey) {
            // Update coordinates gently if not currently dragging
            if (!isEditingPoints) {
                macros.forEach { m ->
                    val triggerEntry = macroNodeWindows["trigger_${m.macro.id}"]
                    if (triggerEntry != null) {
                        triggerEntry.params.x = m.macro.triggerZoneX.roundToInt().coerceAtLeast(0)
                        triggerEntry.params.y = m.macro.triggerZoneY.roundToInt().coerceAtLeast(0)
                        runCatching { windowManager.updateViewLayout(triggerEntry.view, triggerEntry.params) }
                    }
                }
            }
            return
        }

        lastNodeRenderKey = nextKey
        macroNodeWindows.values.forEach { removeWindow(it) }
        macroNodeWindows.clear()

        if (activeProfile == null) return

        // When in Full Hide Mode and NOT editing points, keep the screen 100% clean
        if (visibilityMode == OverlayVisibilityMode.FULL_HIDE_MODE && !isEditingPoints) {
            return
        }

        val halfReticlePx = dpToPx(23)
        macros.filter { it.macro.isEnabled }.forEach { macroWithSteps ->
            val macro = macroWithSteps.macro
            val mode = TriggerMode.fromString(macro.triggerMode)
            val accent = Color(macro.accentColorHex)

            // 1. Draggable target step reticles (visible in Edit Mode)
            if (isEditingPoints) {
                macroWithSteps.sortedSteps.forEach { step ->
                    val winKey = "step_${step.id}"
                    val params = createOverlayParams(
                        gravity = Gravity.TOP or Gravity.START,
                        x = (step.targetX.roundToInt() - halfReticlePx).coerceAtLeast(0),
                        y = (step.targetY.roundToInt() - halfReticlePx).coerceAtLeast(0)
                    )
                    val entry = addComposeWindow(params) {
                        val latestActive by app.activeProfileFlow.collectAsState()
                        val latestStep = latestActive?.macros
                            ?.firstOrNull { it.macro.id == macro.id }
                            ?.steps
                            ?.firstOrNull { it.id == step.id }
                            ?: step

                        DraggableTargetReticleUi(
                            label = macro.name,
                            stepNumber = step.stepIndex + 1,
                            coordX = latestStep.targetX.roundToInt(),
                            coordY = latestStep.targetY.roundToInt(),
                            accentColor = accent,
                            onDragDelta = { dx, dy ->
                                macroNodeWindows[winKey]?.let { w ->
                                    val (maxW, maxH) = screenBoundsPx()
                                    w.params.x = (w.params.x + dx.roundToInt()).coerceIn(0, maxW - halfReticlePx)
                                    w.params.y = (w.params.y + dy.roundToInt()).coerceIn(0, maxH - halfReticlePx)
                                    runCatching { windowManager.updateViewLayout(w.view, w.params) }
                                }
                            },
                            onDragEnd = {
                                val w = macroNodeWindows[winKey] ?: return@DraggableTargetReticleUi
                                val targetX = (w.params.x + halfReticlePx).toFloat()
                                val targetY = (w.params.y + halfReticlePx).toFloat()
                                serviceScope.launch(Dispatchers.IO) {
                                    app.repository.updateStepCoordinates(step.id, targetX, targetY)
                                }
                            },
                            onTapTest = {
                                MacroAccessibilityService.dispatchSinglePoint(
                                    x = latestStep.targetX,
                                    y = latestStep.targetY,
                                    label = macro.name
                                )
                            }
                        )
                    }
                    macroNodeWindows[winKey] = entry
                }
            }

            // 2. Tap-point Trigger Buttons (for TAP_POINT or BOTH trigger modes)
            if (mode == TriggerMode.TAP_POINT || mode == TriggerMode.BOTH) {
                val trigKey = "trigger_${macro.id}"
                val params = createOverlayParams(
                    gravity = Gravity.TOP or Gravity.START,
                    x = macro.triggerZoneX.roundToInt().coerceAtLeast(0),
                    y = macro.triggerZoneY.roundToInt().coerceAtLeast(0)
                )
                val entry = addComposeWindow(params) {
                    val runtime by app.overlayState.collectAsState()
                    val latestActive by app.activeProfileFlow.collectAsState()
                    val latestMacro = latestActive?.macros
                        ?.firstOrNull { it.macro.id == macro.id }
                        ?.macro
                        ?: macro

                    TapPointTriggerButtonUi(
                        label = macro.name,
                        accentColor = accent,
                        isEditing = runtime.isEditingPoints,
                        coordX = latestMacro.triggerZoneX.roundToInt(),
                        coordY = latestMacro.triggerZoneY.roundToInt(),
                        onClick = {
                            app.executeMacroById(macro.id)
                        },
                        onDragDelta = { dx, dy ->
                            macroNodeWindows[trigKey]?.let { w ->
                                val (maxW, maxH) = screenBoundsPx()
                                w.params.x = (w.params.x + dx.roundToInt()).coerceIn(0, maxW - dpToPx(60))
                                w.params.y = (w.params.y + dy.roundToInt()).coerceIn(0, maxH - dpToPx(36))
                                runCatching { windowManager.updateViewLayout(w.view, w.params) }
                            }
                        },
                        onDragEnd = {
                            val w = macroNodeWindows[trigKey] ?: return@TapPointTriggerButtonUi
                            serviceScope.launch(Dispatchers.IO) {
                                app.repository.updateMacroTriggerCoordinates(
                                    macro.id,
                                    w.params.x.toFloat(),
                                    w.params.y.toFloat()
                                )
                            }
                        }
                    )
                }
                macroNodeWindows[trigKey] = entry
            }
        }
    }

    private fun showTemporaryPulseAt(x: Float, y: Float, pulseTimestamp: Long) {
        val halfPx = dpToPx(28)
        val params = createOverlayParams(
            gravity = Gravity.TOP or Gravity.START,
            x = (x.roundToInt() - halfPx).coerceAtLeast(0),
            y = (y.roundToInt() - halfPx).coerceAtLeast(0),
            touchable = false
        )
        val entry = addComposeWindow(params) {
            GesturePulseRingUi(pulseKey = pulseTimestamp)
        }
        mainHandler.postDelayed({
            removeWindow(entry)
        }, 360L)
    }

    private fun toggleDndMode() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        if (!nm.isNotificationPolicyAccessGranted) {
            startActivity(PermissionUtils.createDndAccessIntent())
            app.updateOverlayState {
                it.copy(lastStatusMessage = "يرجى منح إذن عدم الإزعاج من الإعدادات")
            }
            return
        }
        val nextEnable = !app.overlayState.value.isDndActive
        nm.setInterruptionFilter(
            if (nextEnable) {
                NotificationManager.INTERRUPTION_FILTER_PRIORITY
            } else {
                NotificationManager.INTERRUPTION_FILTER_ALL
            }
        )
        app.updateOverlayState {
            it.copy(
                isDndActive = nextEnable,
                lastStatusMessage = if (nextEnable) "تم تفعيل وضع عدم الإزعاج" else "تم إيقاف وضع عدم الإزعاج"
            )
        }
    }

    private fun clearAllWindows() {
        removeWindow(sidebarWindow)
        sidebarWindow = null
        removeWindow(edgePillWindow)
        edgePillWindow = null
        removeWindow(hideZoneWindow)
        hideZoneWindow = null
        removeWindow(crosshairWindow)
        crosshairWindow = null
        macroNodeWindows.values.forEach { removeWindow(it) }
        macroNodeWindows.clear()
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).roundToInt()
    }

    @Suppress("DEPRECATION")
    private fun screenBoundsPx(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        windowManager.defaultDisplay?.getRealMetrics(dm)
        val w = dm.widthPixels.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val h = dm.heightPixels.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels
        return w to h
    }

    companion object {
        const val ACTION_START = "com.example.action.START_OVERLAY"
        const val ACTION_STOP = "com.example.action.STOP_OVERLAY"
        const val ACTION_TOGGLE_VISIBILITY = "com.example.action.TOGGLE_OVERLAY_VISIBILITY"
        private const val CHANNEL_ID = "redpulse_overlay_channel"
        private const val NOTIFICATION_ID = 4091
    }
}
