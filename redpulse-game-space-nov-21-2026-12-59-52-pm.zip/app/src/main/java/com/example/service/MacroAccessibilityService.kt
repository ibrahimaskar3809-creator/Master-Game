package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.example.data.MacroStepEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MacroPulseEvent(
    val x: Float,
    val y: Float,
    val label: String,
    val timestampMs: Long = System.currentTimeMillis()
)

class MacroAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeInstance = this
        _isConnected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No event scraping required; service is solely for user-triggered dispatchGesture taps
    }

    override fun onInterrupt() {
        // No-op
    }

    override fun onDestroy() {
        super.onDestroy()
        if (activeInstance === this) {
            activeInstance = null
        }
        _isConnected.value = false
        serviceScope.cancel()
    }

    fun performSingleTap(
        x: Float,
        y: Float,
        durationMs: Long = 35L,
        label: String = ""
    ): Boolean {
        val safeX = x.coerceAtLeast(1f)
        val safeY = y.coerceAtLeast(1f)
        val safeDuration = durationMs.coerceIn(15L, 500L)

        val path = Path().apply {
            moveTo(safeX, safeY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, safeDuration)
        val gesture = GestureDescription.Builder()
            .addStroke(stroke)
            .build()

        val dispatched = dispatchGesture(gesture, null, null)
        if (dispatched) {
            _pulseEvents.tryEmit(MacroPulseEvent(safeX, safeY, label))
        }
        return dispatched
    }

    fun performMacroSequence(macroName: String, steps: List<MacroStepEntity>): Boolean {
        if (steps.isEmpty()) return false
        val ordered = steps.sortedBy { it.stepIndex }
        serviceScope.launch {
            for (step in ordered) {
                if (step.delayBeforeMs > 0L) {
                    delay(step.delayBeforeMs)
                }
                performSingleTap(
                    x = step.targetX,
                    y = step.targetY,
                    durationMs = step.holdDurationMs,
                    label = macroName
                )
                // Brief inter-gesture breathing window so Android input dispatcher registers sequential strokes
                delay(step.holdDurationMs.coerceAtLeast(25L) + 18L)
            }
        }
        return true
    }

    companion object {
        @Volatile
        private var activeInstance: MacroAccessibilityService? = null

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _pulseEvents = MutableSharedFlow<MacroPulseEvent>(extraBufferCapacity = 16)
        val pulseEvents: SharedFlow<MacroPulseEvent> = _pulseEvents.asSharedFlow()

        fun dispatchMacro(macroName: String, steps: List<MacroStepEntity>): Boolean {
            val service = activeInstance ?: return false
            return service.performMacroSequence(macroName, steps)
        }

        fun dispatchSinglePoint(x: Float, y: Float, label: String = ""): Boolean {
            val service = activeInstance ?: return false
            return service.performSingleTap(x, y, 35L, label)
        }
    }
}
