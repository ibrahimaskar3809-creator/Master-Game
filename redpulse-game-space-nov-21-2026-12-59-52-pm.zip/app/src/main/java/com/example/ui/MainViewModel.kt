package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.OverlayRuntimeState
import com.example.OverlayVisibilityMode
import com.example.RedPulseApp
import com.example.data.GameProfileEntity
import com.example.data.MacroBindingEntity
import com.example.data.MacroStepEntity
import com.example.data.ProfileWithMacros
import com.example.data.SidebarSide
import com.example.data.TriggerMode
import com.example.engine.PermissionStatusSnapshot
import com.example.engine.PermissionUtils
import com.example.engine.TelemetrySnapshot
import com.example.engine.VoiceEngineState
import com.example.service.MacroAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as RedPulseApp
    private val repository = app.repository

    val allProfiles: StateFlow<List<ProfileWithMacros>> = repository.allProfiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeProfile: StateFlow<ProfileWithMacros?> = app.activeProfileFlow

    val telemetry: StateFlow<TelemetrySnapshot> = app.telemetryMonitor.snapshot
    val voiceState: StateFlow<VoiceEngineState> = app.voiceCommandEngine.state
    val overlayState: StateFlow<OverlayRuntimeState> = app.overlayState
    val accessibilityConnected: StateFlow<Boolean> = MacroAccessibilityService.isConnected

    private val _permissions = MutableStateFlow(PermissionUtils.checkAll(application))
    val permissions: StateFlow<PermissionStatusSnapshot> = _permissions.asStateFlow()

    fun refreshPermissions() {
        _permissions.value = PermissionUtils.checkAll(app)
    }

    fun startOverlay() {
        refreshPermissions()
        if (!_permissions.value.overlayGranted) return
        app.startOverlayService()
    }

    fun stopOverlay() {
        app.voiceCommandEngine.stopListening()
        app.stopOverlayService()
    }

    fun setOverlayVisibility(mode: OverlayVisibilityMode) {
        app.updateOverlayState {
            it.copy(
                visibilityMode = mode,
                isEditingPoints = if (mode == OverlayVisibilityMode.FULL_HIDE_MODE) false else it.isEditingPoints
            )
        }
    }

    fun toggleEditPoints() {
        app.updateOverlayState {
            val nextEdit = !it.isEditingPoints
            it.copy(
                isEditingPoints = nextEdit,
                visibilityMode = if (nextEdit && it.visibilityMode == OverlayVisibilityMode.FULL_HIDE_MODE) {
                    OverlayVisibilityMode.SIDEBAR_EXPANDED
                } else {
                    it.visibilityMode
                }
            )
        }
    }

    fun toggleVoiceListening() {
        if (app.voiceCommandEngine.state.value.isListening) {
            app.voiceCommandEngine.stopListening()
        } else {
            app.voiceCommandEngine.startListening()
        }
    }

    fun updateActiveProfileOverlayConfig(
        showKeyword: String,
        hideKeyword: String,
        toggleMode: TriggerMode,
        sidebarSide: SidebarSide,
        showCrosshair: Boolean
    ) {
        val current = activeProfile.value?.profile ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateProfile(
                current.copy(
                    overlayShowVoiceKeyword = showKeyword.trim().ifEmpty { "إظهار" },
                    overlayHideVoiceKeyword = hideKeyword.trim().ifEmpty { "إخفاء" },
                    overlayToggleTriggerMode = toggleMode.name,
                    sidebarSide = sidebarSide.name,
                    showCrosshair = showCrosshair
                )
            )
        }
    }

    fun saveMacro(
        existingMacro: MacroBindingEntity?,
        profileId: Long,
        name: String,
        triggerMode: TriggerMode,
        voiceKeyword: String,
        triggerZoneX: Float,
        triggerZoneY: Float,
        accentColorHex: Long,
        steps: List<MacroStepEntity>
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val macro = (existingMacro ?: MacroBindingEntity(
                profileId = profileId,
                name = name
            )).copy(
                profileId = profileId,
                name = name.trim().ifEmpty { "ماكرو جديد" },
                triggerMode = triggerMode.name,
                voiceKeyword = voiceKeyword.trim(),
                triggerZoneX = triggerZoneX,
                triggerZoneY = triggerZoneY,
                accentColorHex = accentColorHex
            )
            repository.saveMacroWithSteps(macro, steps)
        }
    }

    fun setMacroEnabled(macroId: Long, enabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.setMacroEnabled(macroId, enabled)
        }
    }

    fun deleteMacro(macroId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteMacro(macroId)
        }
    }

    fun testExecuteMacro(macroId: Long): Boolean {
        return app.executeMacroById(macroId)
    }

    fun createProfile(
        name: String,
        genreTag: String,
        sidebarSide: SidebarSide,
        showKeyword: String,
        hideKeyword: String,
        toggleTriggerMode: TriggerMode
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.createProfile(
                name = name,
                genreTag = genreTag,
                sidebarSide = sidebarSide,
                showKeyword = showKeyword,
                hideKeyword = hideKeyword,
                toggleTriggerMode = toggleTriggerMode,
                setActive = true
            )
        }
    }

    fun switchProfile(profileId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.switchActiveProfile(profileId)
        }
    }

    fun duplicateProfile(profileWithMacros: ProfileWithMacros) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.duplicateProfile(profileWithMacros)
        }
    }

    fun deleteProfile(profile: GameProfileEntity) {
        val all = allProfiles.value
        if (all.size <= 1) return
        val fallback = all.firstOrNull { it.profile.id != profile.id }?.profile?.id
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteProfile(profile.id, fallback)
        }
    }
}
