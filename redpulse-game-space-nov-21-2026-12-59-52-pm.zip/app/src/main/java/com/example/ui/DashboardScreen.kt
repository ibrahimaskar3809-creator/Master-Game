package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EditLocationAlt
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.OverlayRuntimeState
import com.example.OverlayVisibilityMode
import com.example.R
import com.example.data.ProfileWithMacros
import com.example.data.SidebarSide
import com.example.data.TriggerMode
import com.example.engine.PermissionStatusSnapshot
import com.example.engine.TelemetrySnapshot
import com.example.ui.theme.CrimsonGlass
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.MechaBorder
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBright
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TacticalAmber
import com.example.ui.theme.TacticalEmerald
import com.example.ui.theme.TacticalRose
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun DashboardScreen(
    activeProfile: ProfileWithMacros?,
    telemetry: TelemetrySnapshot,
    overlayState: OverlayRuntimeState,
    permissions: PermissionStatusSnapshot,
    onRequestOverlayPermission: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onRequestMicPermission: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onStartOverlay: () -> Unit,
    onStopOverlay: () -> Unit,
    onChangeVisibilityMode: (OverlayVisibilityMode) -> Unit,
    onToggleEditPoints: () -> Unit,
    onSaveOverlayConfig: (
        showKeyword: String,
        hideKeyword: String,
        toggleMode: TriggerMode,
        side: SidebarSide,
        crosshair: Boolean
    ) -> Unit
) {
    var showAccessibilityDialog by remember { mutableStateOf(false) }

    val profile = activeProfile?.profile
    var showKeyword by remember(profile?.id) { mutableStateOf(profile?.overlayShowVoiceKeyword ?: "إظهار") }
    var hideKeyword by remember(profile?.id) { mutableStateOf(profile?.overlayHideVoiceKeyword ?: "إخفاء") }
    var toggleMode by remember(profile?.id) {
        mutableStateOf(TriggerMode.fromString(profile?.overlayToggleTriggerMode ?: TriggerMode.BOTH.name))
    }
    var sidebarSide by remember(profile?.id) {
        mutableStateOf(SidebarSide.fromString(profile?.sidebarSide ?: SidebarSide.LEFT.name))
    }
    var showCrosshair by remember(profile?.id) { mutableStateOf(profile?.showCrosshair ?: false) }

    LaunchedEffect(profile?.overlayShowVoiceKeyword, profile?.overlayHideVoiceKeyword, profile?.sidebarSide, profile?.showCrosshair) {
        if (profile != null) {
            showKeyword = profile.overlayShowVoiceKeyword
            hideKeyword = profile.overlayHideVoiceKeyword
            toggleMode = TriggerMode.fromString(profile.overlayToggleTriggerMode)
            sidebarSide = SidebarSide.fromString(profile.sidebarSide)
            showCrosshair = profile.showCrosshair
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // REDMAGIC Hero HUD Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(CutCornerShape(topStart = 20.dp, bottomEnd = 20.dp))
                    .border(1.2.dp, NeonRed.copy(alpha = 0.65f), CutCornerShape(topStart = 20.dp, bottomEnd = 20.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_hud_banner),
                    contentDescription = "خلفية لوحة الألعاب REDMAGIC",
                    modifier = Modifier.matchParentSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    Color(0xE807080D),
                                    Color(0xB80A0C14),
                                    Color(0x6607080D)
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "REDPULSE GAME SPACE",
                                fontFamily = OrbitronFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = TextPrimary,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "طبقة التراكب العائمة ومحرك الماكرو الصوتي",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                        StatusPill(
                            label = if (overlayState.isServiceRunning) "التراكب نشط" else "متوقف",
                            active = overlayState.isServiceRunning
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "الملف النشط:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted
                        )
                        Text(
                            text = profile?.name ?: "PUBG Mobile",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberCyan
                        )
                        Text(
                            text = "• ${activeProfile?.macros?.size ?: 0} ماكرو",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextSecondary
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                if (overlayState.isServiceRunning) {
                                    onStopOverlay()
                                } else if (permissions.overlayGranted) {
                                    onStartOverlay()
                                } else {
                                    onRequestOverlayPermission()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (overlayState.isServiceRunning) ObsidianElevated else NeonRed,
                                contentColor = TextPrimary
                            ),
                            shape = CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("launch_overlay_button")
                        ) {
                            Icon(
                                imageVector = if (overlayState.isServiceRunning) Icons.Default.Stop else Icons.Default.RocketLaunch,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when {
                                    overlayState.isServiceRunning -> "إيقاف التراكب العائم"
                                    permissions.overlayGranted -> "تشغيل التراكب العائم"
                                    else -> "منح إذن الظهور أولاً"
                                },
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }

                    // Quick Visibility Mode Bar when running
                    if (overlayState.isServiceRunning) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = overlayState.visibilityMode == OverlayVisibilityMode.SIDEBAR_EXPANDED,
                                onClick = { onChangeVisibilityMode(OverlayVisibilityMode.SIDEBAR_EXPANDED) },
                                label = { Text("الشريط الجانبي") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CrimsonGlass,
                                    selectedLabelColor = NeonRedBright
                                ),
                                modifier = Modifier.testTag("mode_sidebar_chip")
                            )
                            FilterChip(
                                selected = overlayState.visibilityMode == OverlayVisibilityMode.FULL_HIDE_MODE,
                                onClick = { onChangeVisibilityMode(OverlayVisibilityMode.FULL_HIDE_MODE) },
                                label = { Text("وضع الإخفاء الكامل") },
                                leadingIcon = {
                                    Icon(Icons.Default.VisibilityOff, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CrimsonGlass,
                                    selectedLabelColor = CyberCyan
                                ),
                                modifier = Modifier.testTag("mode_hide_chip")
                            )
                            FilterChip(
                                selected = overlayState.isEditingPoints,
                                onClick = onToggleEditPoints,
                                label = { Text("تحريك النقاط") },
                                leadingIcon = {
                                    Icon(Icons.Default.EditLocationAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CrimsonGlass,
                                    selectedLabelColor = TacticalAmber
                                ),
                                modifier = Modifier.testTag("mode_edit_points_chip")
                            )
                        }
                    }
                }
            }

            // Permissions Checklist Card
            MechaSectionCard(title = "أذونات النظام المطلوبة", subtitle = "تفعيل الصلاحيات الأساسية للطبقة العائمة واللمس والصوت") {
                PermissionRow(
                    icon = Icons.Default.Layers,
                    title = "الظهور فوق التطبيقات (SYSTEM_ALERT_WINDOW)",
                    description = "لعرض الشريط الجانبي ونقاط الماكرو فوق الألعاب",
                    granted = permissions.overlayGranted,
                    buttonTag = "perm_overlay_btn",
                    onAction = onRequestOverlayPermission
                )
                PermissionRow(
                    icon = Icons.Default.AccessibilityNew,
                    title = "خدمة الوصول (AccessibilityService)",
                    description = "لتنفيذ نقرات اللمس التلقائية (dispatchGesture) على النقاط",
                    granted = permissions.accessibilityGranted,
                    buttonTag = "perm_accessibility_btn",
                    onAction = {
                        if (!permissions.accessibilityGranted) {
                            showAccessibilityDialog = true
                        } else {
                            onOpenAccessibilitySettings()
                        }
                    }
                )
                PermissionRow(
                    icon = Icons.Default.Mic,
                    title = "الميكروفون (RECORD_AUDIO)",
                    description = "لالتقاط الأوامر الصوتية السريعة أثناء اللعب",
                    granted = permissions.microphoneGranted,
                    buttonTag = "perm_mic_btn",
                    onAction = onRequestMicPermission
                )
                PermissionRow(
                    icon = Icons.Default.NotificationsActive,
                    title = "إشعارات الخدمة المستمرة",
                    description = "لإبقاء التراكب نشطاً وتبديل الإخفاء السريع من شريط الإشعارات",
                    granted = permissions.notificationsGranted,
                    buttonTag = "perm_notif_btn",
                    onAction = onRequestNotificationPermission
                )
            }

            // Live Telemetry HUD Preview
            MechaSectionCard(title = "بيانات الأداء الحية (Live Telemetry)", subtitle = "قراءات فعلية من النظام للشبكة والمعالج والإطارات") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DashboardMetricCard(
                        label = "FPS",
                        value = "${telemetry.fps}",
                        unit = "/ ${telemetry.refreshRate}Hz",
                        accent = if (telemetry.fps >= 50) TacticalEmerald else TacticalAmber,
                        modifier = Modifier.weight(1f)
                    )
                    DashboardMetricCard(
                        label = "PING",
                        value = if (telemetry.pingMs > 0) "${telemetry.pingMs}" else "--",
                        unit = if (telemetry.pingMs > 0) "ms" else "غير متصل",
                        accent = when {
                            telemetry.pingMs < 0 -> TacticalRose
                            telemetry.pingMs <= 55 -> TacticalEmerald
                            else -> TacticalAmber
                        },
                        modifier = Modifier.weight(1f)
                    )
                }

                // FPS Live Graph
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(38.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(ObsidianVoid)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    val history = telemetry.fpsHistory
                    if (history.size >= 2) {
                        val maxRef = telemetry.refreshRate.coerceAtLeast(60).toFloat()
                        val stepX = size.width / (history.size - 1)
                        val path = Path()
                        history.forEachIndexed { index, fps ->
                            val x = index * stepX
                            val y = size.height - ((fps / maxRef).coerceIn(0.05f, 1f) * size.height)
                            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        drawPath(
                            path = path,
                            color = TacticalEmerald,
                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                    drawLine(
                        color = MechaBorder.copy(alpha = 0.5f),
                        start = Offset(0f, size.height),
                        end = Offset(size.width, size.height),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DashboardProgressMetric(
                        label = "استهلاك CPU",
                        percent = telemetry.cpuPercent,
                        detail = "${telemetry.cpuPercent}%",
                        color = CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                    DashboardProgressMetric(
                        label = "استهلاك GPU",
                        percent = telemetry.gpuPercent,
                        detail = "${telemetry.gpuPercent}% • ${telemetry.tempCelsius.toInt()}°C",
                        color = NeonRedBright,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Hide Mode & Sidebar Customization Card
            MechaSectionCard(
                title = "إعدادات التراكب ووضع الإخفاء الكامل",
                subtitle = "اختر طريقة إظهار وإخفاء الواجهة وموضع الشريط الجانبي"
            ) {
                Text(
                    text = "موقع الشريط الجانبي",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextSecondary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SidebarSide.entries.forEach { side ->
                        FilterChip(
                            selected = sidebarSide == side,
                            onClick = { sidebarSide = side },
                            label = { Text("جانب ${side.labelAr}") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CrimsonGlass,
                                selectedLabelColor = NeonRedBright
                            )
                        )
                    }
                }

                Text(
                    text = "طريقة التفعيل لإظهار / إخفاء الواجهة",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextSecondary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TriggerMode.entries.forEach { mode ->
                        FilterChip(
                            selected = toggleMode == mode,
                            onClick = { toggleMode = mode },
                            label = { Text(mode.labelAr, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CrimsonGlass,
                                selectedLabelColor = CyberCyan
                            )
                        )
                    }
                }

                if (toggleMode == TriggerMode.VOICE || toggleMode == TriggerMode.BOTH) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = showKeyword,
                            onValueChange = { showKeyword = it },
                            label = { Text("أمر صوتي للإظهار") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("show_keyword_input")
                        )
                        OutlinedTextField(
                            value = hideKeyword,
                            onValueChange = { hideKeyword = it },
                            label = { Text("أمر صوتي للإخفاء") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("hide_keyword_input")
                        )
                    }
                }

                if (toggleMode == TriggerMode.TAP_POINT || toggleMode == TriggerMode.BOTH) {
                    Text(
                        text = "إحداثيات نقطة النقر للإخفاء/الإظهار: X=${profile?.tapZoneX?.toInt() ?: 42}, Y=${profile?.tapZoneY?.toInt() ?: 380} (اسحبها من زر تحريك النقاط)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CyberCyan
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CenterFocusStrong,
                            contentDescription = null,
                            tint = NeonRedBright
                        )
                        Text(
                            text = "عرض نقطة التصويب التكتيكية بالمنتصف",
                            style = MaterialTheme.typography.bodyLarge,
                            color = TextPrimary
                        )
                    }
                    Switch(
                        checked = showCrosshair,
                        onCheckedChange = { showCrosshair = it },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = NeonRed,
                            checkedThumbColor = TextPrimary
                        )
                    )
                }

                Button(
                    onClick = {
                        onSaveOverlayConfig(showKeyword, hideKeyword, toggleMode, sidebarSide, showCrosshair)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
                    shape = CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_overlay_config_btn")
                ) {
                    Text("حفظ إعدادات الواجهة للملف النشط", style = MaterialTheme.typography.titleMedium)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    if (showAccessibilityDialog) {
        AlertDialog(
            onDismissRequest = { showAccessibilityDialog = false },
            containerColor = ObsidianElevated,
            title = {
                Text("تفعيل خدمة الوصول للماكرو", color = TextPrimary)
            },
            text = {
                Text(
                    "يستخدم تطبيق RedPulse خدمة الوصول حصرياً لتنفيذ نقرات اللمس التلقائية (dispatchGesture) عند إحداثيات الشاشة التي تحددها بنفسك عند نطق الأمر الصوتي أو الضغط على نقطة التفعيل. لا يجمع التطبيق أي بيانات حساسة من الشاشة.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showAccessibilityDialog = false
                        onOpenAccessibilitySettings()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonRed)
                ) {
                    Text("فتح إعدادات الوصول")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAccessibilityDialog = false }) {
                    Text("إلغاء", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
fun MechaSectionCard(
    title: String,
    subtitle: String? = null,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(CutCornerShape(topStart = 16.dp, bottomEnd = 16.dp))
            .background(ObsidianSurface)
            .border(1.dp, MechaBorder, CutCornerShape(topStart = 16.dp, bottomEnd = 16.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .height(18.dp)
                        .background(NeonRed)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
            }
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMuted
                )
            }
        }
        content()
    }
}

@Composable
private fun StatusPill(label: String, active: Boolean) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (active) TacticalEmerald.copy(alpha = 0.16f) else ObsidianElevated)
            .border(
                1.dp,
                if (active) TacticalEmerald else MechaBorder,
                RoundedCornerShape(20.dp)
            )
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (active) TacticalEmerald else TextMuted)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = if (active) TacticalEmerald else TextSecondary
        )
    }
}

@Composable
private fun PermissionRow(
    icon: ImageVector,
    title: String,
    description: String,
    granted: Boolean,
    buttonTag: String,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianCard)
            .border(
                1.dp,
                if (granted) TacticalEmerald.copy(alpha = 0.35f) else MechaBorder,
                RoundedCornerShape(10.dp)
            )
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (granted) TacticalEmerald else NeonRedBright,
            modifier = Modifier.size(24.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = TextMuted
            )
        }
        if (granted) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "مفعّل",
                    tint = TacticalEmerald,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "مفعّل",
                    style = MaterialTheme.typography.labelLarge,
                    color = TacticalEmerald
                )
            }
        } else {
            OutlinedButton(
                onClick = onAction,
                shape = CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp),
                modifier = Modifier.testTag(buttonTag)
            ) {
                Icon(
                    imageVector = Icons.Default.WarningAmber,
                    contentDescription = null,
                    tint = TacticalAmber,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("تفعيل", color = TextPrimary)
            }
        }
    }
}

@Composable
private fun DashboardMetricCard(
    label: String,
    value: String,
    unit: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianCard)
            .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Text(
            text = label,
            fontFamily = RajdhaniFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = TextMuted
        )
        Row(
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = value,
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                color = accent
            )
            Text(
                text = unit,
                fontFamily = RajdhaniFontFamily,
                fontSize = 12.sp,
                color = TextSecondary,
                modifier = Modifier.padding(bottom = 3.dp)
            )
        }
    }
}

@Composable
private fun DashboardProgressMetric(
    label: String,
    percent: Int,
    detail: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianCard)
            .border(1.dp, MechaBorder, RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Text(
                detail,
                fontFamily = RajdhaniFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = TextPrimary
            )
        }
        LinearProgressIndicator(
            progress = { (percent / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = ObsidianVoid
        )
    }
}
